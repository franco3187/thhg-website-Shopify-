function ContactPage() {
  const [form, setForm] = React.useState({ name: '', email: '', subject: '', message: '' });
  const [sent, setSent] = React.useState(false);
  const update = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));
  const handleSubmit = (e) => { e.preventDefault(); setSent(true); };

  const inputStyle = { border: `1px solid ${C.tan}`, background: '#fff', color: C.ink };

  return (
    <>
      <PageHero
        eyebrow="Contact"
        title="Say hello. Share a rescue. Start a conversation."
        subtitle="Press, partnerships, rescue stories, wholesale, or just a note to say thanks — this inbox is read by real humans who care about the mission."
        badge={{ title: 'Contact', eyebrow: 'Get in touch', highlight: "Let's talk", copy: 'Every message lands directly with the team. We read every single one.' }}
      />

      <section className="py-16 sm:py-20 md:py-24" style={{ background: C.cream }}>
        <div className="mx-auto grid max-w-6xl gap-8 px-5 sm:px-6 lg:grid-cols-[1.2fr_0.8fr] lg:px-8">
          <div className="p-8 sm:p-10" style={{ background: '#fff', border: `1px solid ${C.tan}`, boxShadow: '0 14px 40px rgba(15,26,46,0.07)', borderTop: `4px solid ${C.gold}` }}>
            <SectionHeader eyebrow="Drop a note" title="Tell us what's on your mind." />
            {sent ? (
              <div className="mt-8 p-6" style={{ background: C.cream, border: `1px dashed ${C.red}` }}>
                <StarRow color={C.red} />
                <h3 className="thhg-rye mt-3 text-2xl" style={{ color: C.navy2 }}>Message received.</h3>
                <p className="thhg-baskerville mt-2 text-sm leading-7" style={{ color: C.brown }}>Thanks for reaching out. We'll be in touch soon — usually within a day or two.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="mt-8 grid gap-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="block">
                    <span className="thhg-oswald text-[10px] uppercase tracking-[0.22em]" style={{ color: C.brown }}>Name</span>
                    <input type="text" required value={form.name} onChange={update('name')} className="thhg-baskerville mt-2 w-full px-4 py-3 text-sm outline-none" style={inputStyle} />
                  </label>
                  <label className="block">
                    <span className="thhg-oswald text-[10px] uppercase tracking-[0.22em]" style={{ color: C.brown }}>Email</span>
                    <input type="email" required value={form.email} onChange={update('email')} className="thhg-baskerville mt-2 w-full px-4 py-3 text-sm outline-none" style={inputStyle} />
                  </label>
                </div>
                <label className="block">
                  <span className="thhg-oswald text-[10px] uppercase tracking-[0.22em]" style={{ color: C.brown }}>Subject</span>
                  <select value={form.subject} onChange={update('subject')} className="thhg-baskerville mt-2 w-full px-4 py-3 text-sm outline-none" style={inputStyle}>
                    <option value="">Select a topic…</option>
                    <option>Rescue story / spotlight</option>
                    <option>Press & media</option>
                    <option>Wholesale & partnerships</option>
                    <option>Product question</option>
                    <option>Just saying hi</option>
                  </select>
                </label>
                <label className="block">
                  <span className="thhg-oswald text-[10px] uppercase tracking-[0.22em]" style={{ color: C.brown }}>Message</span>
                  <textarea required rows={5} value={form.message} onChange={update('message')} className="thhg-baskerville mt-2 w-full px-4 py-3 text-sm outline-none" style={inputStyle}></textarea>
                </label>
                <button type="submit" className="thhg-shine thhg-oswald mt-2 self-start px-6 py-3 text-xs font-semibold uppercase tracking-[0.22em]" style={{ background: C.red, color: C.cream }}>Send message →</button>
              </form>
            )}
          </div>

          <div className="grid content-start gap-5">
            <div className="p-6" style={{ background: C.navy, color: C.cream }}>
              <Eyebrow color={C.goldLt}>Email</Eyebrow>
              <div className="thhg-rye mt-3 text-2xl">hello@thehappyhuntinggrounds.org</div>
              <p className="thhg-baskerville mt-3 text-sm leading-7" style={{ color: '#E7D9BE' }}>We read everything. Expect a real reply.</p>
            </div>
            <div className="p-6" style={{ background: '#fff', border: `1px solid ${C.tan}` }}>
              <Eyebrow>Instagram</Eyebrow>
              <a href="https://instagram.com/thehappyhuntinggrounds" target="_blank" rel="noopener noreferrer" className="thhg-rye mt-3 block text-2xl" style={{ color: C.navy2 }}>@thehappyhuntinggrounds</a>
              <p className="thhg-baskerville mt-3 text-sm leading-7" style={{ color: C.brown }}>DMs are open for rescue stories and spotlights.</p>
            </div>
            <div className="p-6" style={{ background: C.cream, border: `1px solid ${C.tan}` }}>
              <Eyebrow>Partnerships</Eyebrow>
              <div className="thhg-rye mt-3 text-xl" style={{ color: C.navy2 }}>Rescues. Shelters. Veteran orgs.</div>
              <p className="thhg-baskerville mt-3 text-sm leading-7" style={{ color: C.brown }}>We're always looking for mission-aligned partners. Pitch us — we'll listen.</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

window.ContactPage = ContactPage;
