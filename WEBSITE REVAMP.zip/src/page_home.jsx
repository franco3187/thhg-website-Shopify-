// Home page
// -----------------------------------------------------------------------------

function HomePage({ navigate }) {
  const [email, setEmail] = React.useState('');
  const [joined, setJoined] = React.useState(false);

  const handleJoin = (e) => {
    e.preventDefault();
    if (email.trim()) setJoined(true);
  };

  const pillars = [
    {
      eyebrow: 'Pillar one',
      title: 'Rescue first',
      copy: 'A portion of every order funds shelter essentials — beds, enrichment toys, vet care, and foster support for dogs waiting on their second chance.',
      cta: 'See impact', onCta: () => navigate('lives-changed'),
    },
    {
      eyebrow: 'Pillar two',
      title: 'Healing through dogs',
      copy: 'Dogs heal people. Veterans. Grieving families. Survivors. Our mission actively supports programs that put dogs in the lives of people who need them most.',
      cta: 'Our story', onCta: () => navigate('our-story'),
    },
    {
      eyebrow: 'Pillar three',
      title: 'Full transparency',
      copy: 'Every dollar donated is documented. Every rescue spotlighted. Every bed sponsored is shown. We show the receipts because accountability is how real community is built.',
      cta: 'View updates', onCta: () => navigate('lives-changed'),
    },
  ];

  const shopCards = [
    {
      eyebrow: 'Apparel',
      title: 'Second Chance Collection',
      copy: 'Bold heritage-style pieces that carry the mission on their sleeve. Hoodies, tees, and caps for the tribe.',
      cta: 'Shop apparel', onCta: () => navigate('apparel'),
      media: <Placeholder label="APPAREL LOOKBOOK" aspect="4/5" tone="navy" />,
    },
    {
      eyebrow: 'For the dogs',
      title: 'Munchables',
      copy: 'Single-ingredient, all-natural treats for good dogs everywhere. Made with intention. Sold with purpose.',
      cta: 'Shop treats', onCta: () => navigate('munchables'),
      media: <Placeholder label="MUNCHABLES PACKAGING" aspect="4/5" tone="warm" />,
    },
    {
      eyebrow: 'Healing story',
      title: 'The THHG Book',
      copy: 'A story for every family who has loved and lost a dog. Written from the heart. Illustrated with warmth.',
      cta: 'View the book', onCta: () => navigate('shop'),
      media: <Placeholder label="THE BOOK" aspect="4/5" tone="red" />,
    },
  ];

  return (
    <>
      <PageHero
        eyebrow="Saving lives on both ends of the leash"
        title="Built from love, loss, rescue, and a tribe that believes shopping should mean something."
        subtitle="The Happy Hunting Grounds is where second chances are celebrated, shelter dogs find voices, and every purchase does more than just arrive at your door."
        badge={{
          title: 'Shop With Purpose',
          eyebrow: 'Brand promise',
          highlight: 'Good vibes save lives',
          copy: '25% minimum of every purchase goes directly back to rescue, shelter support, and veteran healing.',
        }}
        cta={{
          label: 'Shop the mission',
          secondary: 'Read our story',
          onSecondary: () => navigate('our-story'),
        }}
        onCta={() => navigate('shop')}
      />

      <Marquee items={['Your vibe attracts your tribe', 'Second chances', 'Built on transparency', 'Community over clout', 'Good vibes save lives']} />

      {/* ─── Mission pillars ─── */}
      <section className="py-16 sm:py-20 md:py-24" style={{ background: C.creamLt }}>
        <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
          <div className="mb-12 md:mb-14">
            <SectionHeader
              eyebrow="Why we exist"
              title="A brand rooted in second chances."
              copy="We started because a dog named April changed everything — and losing her made us want to keep that love moving forward in the world."
            />
          </div>
          <ScrollReveal>
            <CardGrid items={pillars} />
          </ScrollReveal>
        </div>
      </section>

      {/* ─── April gallery strip — editorial, tighter ─── */}
      <section className="py-16 sm:py-20" style={{ background: C.cream }}>
        <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-14">
            {/* Text column */}
            <div className="relative">
              <div className="thhg-oswald text-[11px] uppercase tracking-[0.28em]" style={{ color: C.red }}>
                ★ Our story in brief ★
              </div>
              <h2 className="thhg-rye mt-4 text-[34px] leading-[1.05] sm:text-[44px]" style={{ color: C.navy2 }}>
                Before the brand,<br/>there was April.
              </h2>
              <div className="mt-5 max-w-xs">
                <Rule color={C.red} />
              </div>
              <p className="thhg-baskerville mt-6 text-[15px] leading-[1.85] sm:text-[17px]" style={{ color: C.brown }}>
                A rescue who healed a family — and built the soul of everything you see here.
                When she passed, the grief was real. So was the decision to honor her by helping other dogs,
                other families, and other people who needed exactly what she gave us.
              </p>
              <blockquote className="thhg-playfair mt-7 border-l-[3px] pl-5 text-[19px] italic leading-[1.6]" style={{ color: C.navy2, borderColor: C.red }}>
                "We didn't build this to become a brand. We built it because the love was too big to stay quiet."
              </blockquote>
              <button
                onClick={() => navigate('our-story')}
                className="thhg-oswald mt-7 inline-flex items-center gap-2 border-b-2 pb-1 text-xs font-semibold uppercase tracking-[0.24em]"
                style={{ color: C.red, borderColor: C.red }}
              >
                Read the full story →
              </button>
            </div>

            {/* Editorial photo grid */}
            <div className="grid gap-3 sm:grid-cols-6 sm:grid-rows-[180px_180px_180px]">
              <div className="sm:col-span-4 sm:row-span-2">
                <Placeholder label="APRIL — RED RUFFLE" aspect="auto" tone="warm" className="h-full min-h-[240px]" />
              </div>
              <div className="sm:col-span-2 sm:row-span-1">
                <Placeholder label="APRIL — RESTING" aspect="auto" tone="navy" className="h-full min-h-[180px]" />
              </div>
              <div className="sm:col-span-2 sm:row-span-1">
                <Placeholder label="APRIL + FRANCO" aspect="auto" tone="red" className="h-full min-h-[180px]" />
              </div>
              <div className="sm:col-span-6 sm:row-span-1 flex items-center justify-between gap-4 px-1">
                <div className="thhg-mono text-[10px] uppercase tracking-[0.22em]" style={{ color: C.brown, opacity: 0.7 }}>
                  Photos · April 2019 – 2023
                </div>
                <div className="thhg-rye text-sm" style={{ color: C.red }}>★ ★ ★</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Shop preview ─── */}
      <section className="py-16 sm:py-20 md:py-24" style={{ background: C.creamLt }}>
        <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
          <div className="mb-10 flex flex-col gap-5 sm:mb-12 sm:flex-row sm:items-end sm:justify-between">
            <SectionHeader eyebrow="Shop with purpose" title="Every product carries the mission." />
            <button
              onClick={() => navigate('shop')}
              className="thhg-oswald shrink-0 self-start border-b-2 pb-1 text-[11px] font-semibold uppercase tracking-[0.24em]"
              style={{ color: C.navy2, borderColor: C.navy2 }}
            >
              Browse all collections →
            </button>
          </div>
          <CardGrid items={shopCards} />
        </div>
      </section>

      {/* ─── Instagram / where the money goes ─── */}
      <section className="relative py-16 sm:py-20 md:py-24" style={{ background: C.navy, color: C.cream }}>
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.06]"
          style={{ backgroundImage: `radial-gradient(${C.cream} 1px, transparent 1px)`, backgroundSize: '24px 24px' }}
        />
        <div className="relative mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
          <div className="mb-10 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <Eyebrow color={C.goldLt}>Where the money goes</Eyebrow>
              <h2 className="thhg-rye mt-4 text-3xl leading-[1.08] sm:text-4xl md:text-5xl" style={{ color: C.cream }}>
                Follow along — we show every dollar.
              </h2>
              <p className="thhg-baskerville mt-5 max-w-xl text-[15px] leading-[1.85]" style={{ color: '#E7D9BE' }}>
                Real rescues, real receipts. Instagram is where we document the day-to-day — beds funded, dogs spotlighted,
                families reunited. This is the accountability.
              </p>
            </div>
            <a
              href="https://instagram.com/thehappyhuntinggrounds"
              target="_blank"
              rel="noopener noreferrer"
              className="thhg-shine thhg-oswald shrink-0 self-start border-2 px-5 py-3 text-xs font-semibold uppercase tracking-[0.22em] transition hover:-translate-y-0.5"
              style={{ color: C.cream, borderColor: C.gold }}
            >
              @thehappyhuntinggrounds ↗
            </a>
          </div>

          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-6">
            {[
              { label: 'BEDS FUNDED', tag: 'Q1' },
              { label: 'RESCUE SPOTLIGHT', tag: 'LIVE' },
              { label: 'MUNCHABLES DROP', tag: 'NEW' },
              { label: 'VET CARE RECEIPT', tag: 'PROOF' },
              { label: 'VETERAN PAIRING', tag: 'STORY' },
              { label: 'SHELTER VISIT', tag: 'VLOG' },
            ].map((p, i) => (
              <a
                key={i}
                href="https://instagram.com/thehappyhuntinggrounds"
                target="_blank"
                rel="noopener noreferrer"
                className="thhg-card group relative aspect-square overflow-hidden"
              >
                <Placeholder
                  label={p.label}
                  aspect="1/1"
                  tone={i % 3 === 0 ? 'navy' : i % 3 === 1 ? 'red' : 'warm'}
                  className="h-full"
                />
                <div
                  className="thhg-oswald absolute left-2 top-2 px-2 py-1 text-[9px] font-semibold uppercase tracking-[0.18em]"
                  style={{ background: C.gold, color: C.navy }}
                >
                  {p.tag}
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Impact stats band ─── */}
      <section className="py-16 sm:py-20" style={{ background: C.navy2, color: C.cream, borderTop: `3px solid ${C.gold}`, borderBottom: `3px solid ${C.gold}` }}>
        <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
          <SectionHeader
            eyebrow="Where it goes"
            title="Your purchase does more than ship to your door."
            titleColor={C.cream}
            eyebrowColor={C.goldLt}
            copy="We document every donation, every rescue spotlight, every wobbler purchased and bed sponsored. You should know exactly what your support is doing in the world."
          />
          <div className="mt-10 grid gap-6 sm:grid-cols-3">
            {[
              { stat: 'Shelter beds',    copy: 'Sponsored directly through product sales for dogs waiting on adoption.' },
              { stat: 'Enrichment toys', copy: 'Wobblers and enrichment tools donated to keep shelter dogs mentally healthy.' },
              { stat: 'Veteran support', copy: 'Programs connecting veterans with rescue dogs as part of healing-focused initiatives.' },
            ].map(({ stat, copy }) => (
              <div key={stat} className="p-6" style={{ border: '1px solid rgba(255,255,255,0.12)', background: 'rgba(255,255,255,0.04)' }}>
                <div className="thhg-rye text-2xl" style={{ color: C.goldLt }}>★</div>
                <div className="thhg-rye mt-3 text-2xl" style={{ color: C.cream }}>{stat}</div>
                <p className="thhg-baskerville mt-3 text-sm leading-7" style={{ color: '#C8C0B0' }}>{copy}</p>
              </div>
            ))}
          </div>
          <button
            onClick={() => navigate('lives-changed')}
            className="thhg-shine thhg-oswald mt-10 border-2 px-6 py-3 text-sm font-semibold uppercase tracking-[0.18em] transition hover:-translate-y-0.5"
            style={{ color: C.cream, borderColor: C.gold }}
          >
            See the full impact →
          </button>
        </div>
      </section>

      {/* ─── Email capture ─── */}
      <section className="py-16 sm:py-20" style={{ background: C.creamLt }}>
        <div className="mx-auto max-w-5xl px-5 sm:px-6 lg:px-8">
          <div className="overflow-hidden border bg-white" style={{ borderColor: C.tan, boxShadow: '0 20px 60px rgba(15,26,46,0.08)' }}>
            <div className="grid lg:grid-cols-2">
              <div className="p-8 sm:p-10" style={{ background: C.cream, borderTop: `4px solid ${C.gold}` }}>
                <Eyebrow>Stay connected</Eyebrow>
                <h2 className="thhg-rye mt-4 text-3xl leading-tight sm:text-4xl" style={{ color: C.navy2 }}>Join the pack.</h2>
                <p className="thhg-baskerville mt-4 text-sm leading-7" style={{ color: C.brown }}>
                  Updates on new products, rescue spotlights, and what your purchases are actually doing in the world. No fluff. Just mission.
                </p>
                {joined ? (
                  <p className="thhg-rye mt-8 text-2xl" style={{ color: C.navy2 }}>Welcome to the pack. ★</p>
                ) : (
                  <form onSubmit={handleJoin} className="mt-8 flex flex-col gap-3 sm:flex-row">
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Your email address"
                      required
                      className="thhg-baskerville min-w-0 flex-1 border bg-white px-5 py-3 text-sm outline-none"
                      style={{ borderColor: C.tan, color: C.ink }}
                    />
                    <button
                      type="submit"
                      className="thhg-oswald shrink-0 px-6 py-3 text-sm font-semibold uppercase tracking-[0.18em]"
                      style={{ background: C.red, color: C.cream }}
                    >
                      Join the pack
                    </button>
                  </form>
                )}
              </div>
              <div className="p-8 sm:p-10" style={{ background: C.navy, color: C.cream }}>
                <Eyebrow color={C.goldLt}>What you'll get</Eyebrow>
                <ul className="mt-6 space-y-5">
                  {[
                    'New drop announcements before they go public.',
                    'Monthly rescue spotlights showing exactly where your support went.',
                    'Behind-the-scenes stories from the brand and the mission.',
                    'Early access to seasonal fundraising campaigns.',
                  ].map((item) => (
                    <li key={item} className="flex gap-3">
                      <span className="thhg-rye shrink-0" style={{ color: C.gold }}>★</span>
                      <span className="thhg-baskerville text-sm leading-7" style={{ color: '#E7D9BE' }}>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

window.HomePage = HomePage;
