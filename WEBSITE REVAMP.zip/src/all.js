/* ===== src/shared.jsx ===== */
// Shared UI: placeholders, icons, marquee, section headers, cards, hero
// Exposes: Placeholder, LogoMark, StarRow, Marquee, Eyebrow, SectionHeader,
//          CardGrid, StatCard, Rule, PageHero, ScrollReveal, useTweaks
// -----------------------------------------------------------------------------

const {
  useState,
  useEffect,
  useRef,
  useMemo,
  useCallback
} = React;

// ─── Palette constants ────────────────────────────────────────────────────────
const C = {
  navy: '#0F1A2E',
  navy2: '#1B2A4A',
  red: '#B5282A',
  redDk: '#7A1A1C',
  gold: '#C8882A',
  goldLt: '#E8A83A',
  cream: '#F5EDD8',
  creamLt: '#FDFAF4',
  tan: '#D4B483',
  ink: '#1C1510',
  brown: '#4A3822'
};

// ─── Tweaks hook ──────────────────────────────────────────────────────────────
function useTweaks() {
  const [t, setT] = useState(window.__thhgTweaks || {
    heroVariant: 'badge'
  });
  useEffect(() => {
    const h = () => setT({
      ...window.__thhgTweaks
    });
    window.addEventListener('thhg-tweaks-changed', h);
    return () => window.removeEventListener('thhg-tweaks-changed', h);
  }, []);
  return t;
}

// ─── Logo mark — uses the uploaded THHG logo image ────────────────────────────
function LogoMark({
  size = 48,
  animate = true
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: `${animate ? 'thhg-logo-pop' : ''} relative shrink-0 overflow-hidden rounded-full`,
    style: {
      width: size,
      height: size,
      background: '#fff'
    },
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("img", {
    src: "assets/thhg-logo.jpeg",
    alt: "The Happy Hunting Grounds",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block'
    }
  }));
}

// ─── Placeholder image block ──────────────────────────────────────────────────
function Placeholder({
  label,
  aspect = '4/3',
  tone = 'navy',
  className = '',
  children
}) {
  const toneClass = tone === 'warm' ? 'thhg-placeholder-warm' : tone === 'red' ? 'thhg-placeholder-red' : 'thhg-placeholder';
  const labelColor = tone === 'warm' ? C.brown : C.cream;
  return /*#__PURE__*/React.createElement("div", {
    className: `relative overflow-hidden ${toneClass} ${className}`,
    style: {
      aspectRatio: aspect
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "absolute inset-0 flex flex-col items-center justify-center p-4 text-center"
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-mono text-[10px] uppercase tracking-[0.22em]",
    style: {
      color: labelColor,
      opacity: 0.7
    }
  }, "\u25B8 ", label), children));
}

// ─── Star row ─────────────────────────────────────────────────────────────────
function StarRow({
  color = C.gold,
  size = 'text-base',
  count = 3
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: `thhg-star-pop inline-flex gap-2 ${size}`,
    style: {
      color
    },
    "aria-hidden": "true"
  }, Array.from({
    length: count
  }).map((_, i) => /*#__PURE__*/React.createElement("span", {
    key: i
  }, "\u2605")));
}

// ─── Marquee band ─────────────────────────────────────────────────────────────
function Marquee({
  items,
  tone = 'gold'
}) {
  const track = useMemo(() => [...items, ...items, ...items, ...items], [items]);
  const bg = tone === 'gold' ? C.gold : tone === 'red' ? C.red : C.navy;
  const fg = tone === 'gold' ? C.navy : C.cream;
  const accent = tone === 'gold' ? C.red : C.gold;
  return /*#__PURE__*/React.createElement("div", {
    className: "overflow-hidden py-3 sm:py-4",
    style: {
      background: bg,
      borderTop: `2px solid ${accent}`,
      borderBottom: `2px solid ${accent}`
    },
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-marquee flex w-max items-center gap-x-6 sm:gap-x-8"
  }, track.map((item, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "thhg-rye flex shrink-0 items-center gap-4 sm:gap-6 text-sm sm:text-base",
    style: {
      color: fg
    }
  }, /*#__PURE__*/React.createElement("span", null, item), /*#__PURE__*/React.createElement("span", {
    style: {
      color: accent
    }
  }, "\u2605")))));
}

// ─── Eyebrow ─────────────────────────────────────────────────────────────────
function Eyebrow({
  children,
  color = C.red,
  className = ''
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: `thhg-oswald inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.28em] ${className}`,
    style: {
      color
    }
  }, /*#__PURE__*/React.createElement("span", null, "\u2605"), /*#__PURE__*/React.createElement("span", null, children), /*#__PURE__*/React.createElement("span", null, "\u2605"));
}

// ─── Section header ──────────────────────────────────────────────────────────
function SectionHeader({
  eyebrow,
  title,
  copy,
  align = 'left',
  titleColor,
  eyebrowColor = C.red
}) {
  const alignClass = align === 'center' ? 'mx-auto text-center' : '';
  return /*#__PURE__*/React.createElement("div", {
    className: `max-w-3xl ${alignClass}`
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    color: eyebrowColor
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    className: "thhg-rye mt-4 text-3xl leading-[1.1] sm:text-4xl md:text-5xl",
    style: {
      color: titleColor || C.navy2
    }
  }, title), copy && /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-5 text-base leading-[1.75] sm:text-[17px]",
    style: {
      color: C.brown
    }
  }, copy));
}

// ─── Western rule ────────────────────────────────────────────────────────────
function Rule({
  className = '',
  color = C.red
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: `flex items-center gap-3 ${className}`,
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("div", {
    className: "h-px flex-1",
    style: {
      background: `linear-gradient(90deg, transparent, ${color}, transparent)`
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color
    }
  }, "\u2605"), /*#__PURE__*/React.createElement("div", {
    className: "h-px flex-1",
    style: {
      background: `linear-gradient(90deg, transparent, ${color}, transparent)`
    }
  }));
}

// ─── Card grid ────────────────────────────────────────────────────────────────
function CardGrid({
  items,
  dark = false,
  cols = 3
}) {
  const colsClass = cols === 2 ? 'sm:grid-cols-2' : 'sm:grid-cols-2 lg:grid-cols-3';
  return /*#__PURE__*/React.createElement("div", {
    className: `grid gap-5 sm:gap-6 ${colsClass}`
  }, items.map((item, i) => /*#__PURE__*/React.createElement("article", {
    key: item.title + i,
    className: "thhg-card group relative overflow-hidden border",
    style: {
      background: dark ? 'rgba(255,255,255,0.04)' : '#fff',
      borderColor: dark ? 'rgba(255,255,255,0.12)' : C.tan,
      boxShadow: dark ? 'none' : '0 14px 40px rgba(15,26,46,0.07)'
    }
  }, item.media && /*#__PURE__*/React.createElement("div", {
    className: "relative"
  }, item.media, /*#__PURE__*/React.createElement("div", {
    className: "absolute left-0 top-0 m-3"
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.2em]",
    style: {
      background: C.cream,
      color: C.navy2
    }
  }, item.eyebrow))), /*#__PURE__*/React.createElement("div", {
    className: "p-6",
    style: {
      borderTop: item.media ? `3px solid ${C.gold}` : 'none'
    }
  }, !item.media && /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald text-[11px] uppercase tracking-[0.25em]",
    style: {
      color: dark ? C.goldLt : C.red
    }
  }, item.eyebrow), /*#__PURE__*/React.createElement("h3", {
    className: "thhg-rye mt-3 text-2xl leading-tight sm:text-[26px]",
    style: {
      color: dark ? C.cream : C.navy2
    }
  }, item.title), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-3 text-sm leading-7",
    style: {
      color: dark ? '#E7D9BE' : C.brown
    }
  }, item.copy), item.cta && /*#__PURE__*/React.createElement("button", {
    onClick: item.onCta,
    className: "thhg-oswald mt-5 inline-flex items-center gap-2 border-b-2 pb-1 text-[11px] font-semibold uppercase tracking-[0.24em]",
    style: {
      color: dark ? C.goldLt : C.red,
      borderColor: dark ? C.goldLt : C.red
    }
  }, item.cta, " ", /*#__PURE__*/React.createElement("span", null, "\u2192"))))));
}

// ─── Stat card ───────────────────────────────────────────────────────────────
function StatCard({
  value,
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "border bg-white p-6",
    style: {
      borderColor: C.tan,
      boxShadow: '0 10px 30px rgba(15,26,46,0.05)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye text-4xl",
    style: {
      color: C.red
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald mt-2 text-[11px] uppercase tracking-[0.18em]",
    style: {
      color: C.brown
    }
  }, label));
}

// ─── Scroll reveal ───────────────────────────────────────────────────────────
function ScrollReveal({
  children,
  delay = 0,
  className = ''
}) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) {
        setVisible(true);
        obs.disconnect();
      }
    }, {
      threshold: 0.1
    });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    className: className,
    style: {
      opacity: visible ? 1 : 0,
      transform: visible ? 'translateY(0)' : 'translateY(24px)',
      transition: `opacity 700ms ease ${delay}ms, transform 700ms ease ${delay}ms`
    }
  }, children);
}

// ─── Page Hero ───────────────────────────────────────────────────────────────
function PageHero({
  eyebrow,
  title,
  subtitle,
  badge,
  cta,
  onCta,
  variant
}) {
  const tweaks = useTweaks();
  const v = variant || tweaks.heroVariant || 'badge';
  return /*#__PURE__*/React.createElement("section", {
    className: "relative overflow-hidden",
    style: {
      background: C.navy
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pointer-events-none absolute inset-0",
    style: {
      backgroundImage: `radial-gradient(circle at 15% 10%, rgba(200,136,42,0.16), transparent 42%), radial-gradient(circle at 88% 90%, rgba(181,40,42,0.18), transparent 38%)`
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "pointer-events-none absolute inset-0 opacity-[0.08]",
    style: {
      backgroundImage: `radial-gradient(${C.cream} 1px, transparent 1px)`,
      backgroundSize: '24px 24px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "relative mx-auto grid max-w-7xl gap-10 px-5 py-14 sm:px-6 sm:py-20 lg:grid-cols-[1.15fr_0.85fr] lg:gap-14 lg:px-8 lg:py-24"
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative z-10"
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    color: C.goldLt
  }, eyebrow), /*#__PURE__*/React.createElement("h1", {
    className: "thhg-rye mt-5 max-w-2xl text-[38px] leading-[1.04] sm:text-5xl lg:text-[64px]",
    style: {
      color: C.cream
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    className: "mt-6 max-w-md"
  }, /*#__PURE__*/React.createElement(Rule, {
    color: C.red
  })), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-6 max-w-xl text-[15px] leading-[1.85] sm:text-[17px]",
    style: {
      color: '#E7D9BE'
    }
  }, subtitle), cta && /*#__PURE__*/React.createElement("div", {
    className: "mt-8 flex flex-wrap items-center gap-4"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onCta,
    className: "thhg-shine thhg-oswald px-6 py-3.5 text-xs font-semibold uppercase tracking-[0.22em]",
    style: {
      background: C.red,
      color: C.cream
    }
  }, cta.label), cta.secondary && /*#__PURE__*/React.createElement("button", {
    onClick: cta.onSecondary,
    className: "thhg-oswald border-b-2 pb-1 text-xs font-semibold uppercase tracking-[0.22em]",
    style: {
      color: C.goldLt,
      borderColor: C.goldLt
    }
  }, cta.secondary, " \u2192"))), /*#__PURE__*/React.createElement("div", {
    className: "relative z-10 flex items-center justify-center"
  }, v === 'badge' && /*#__PURE__*/React.createElement(HeroBadge, {
    badge: badge
  }), v === 'poster' && /*#__PURE__*/React.createElement(HeroPoster, {
    badge: badge
  }), v === 'portrait' && /*#__PURE__*/React.createElement(HeroPortrait, {
    badge: badge
  }))), /*#__PURE__*/React.createElement("div", {
    className: "relative h-3",
    style: {
      background: C.gold
    }
  }));
}
function HeroBadge({
  badge
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "thhg-hero-card w-full max-w-sm",
    style: {
      border: `3px solid ${C.gold}`,
      background: C.cream,
      padding: 14,
      boxShadow: '0 16px 60px rgba(0,0,0,0.35)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: `linear-gradient(160deg, ${C.navy2}, #162038)`,
      padding: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col items-center border p-6 text-center",
    style: {
      borderColor: 'rgba(255,255,255,0.12)',
      background: 'linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02))'
    }
  }, /*#__PURE__*/React.createElement(StarRow, {
    color: C.gold
  }), /*#__PURE__*/React.createElement("div", {
    className: "mt-4"
  }, /*#__PURE__*/React.createElement(LogoMark, {
    size: 110
  })), /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye mt-4 text-xl",
    style: {
      color: C.cream
    }
  }, "The Happy Hunting Grounds"), /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye mt-1 text-lg",
    style: {
      color: C.red
    }
  }, badge.title), /*#__PURE__*/React.createElement("div", {
    className: "mt-4 w-full p-4",
    style: {
      borderTop: `4px solid ${C.gold}`,
      background: C.cream
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald text-[10px] uppercase tracking-[0.25em]",
    style: {
      color: C.navy2
    }
  }, badge.eyebrow), /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye mt-2 text-xl",
    style: {
      color: C.navy2
    }
  }, badge.highlight), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-2 text-xs leading-6",
    style: {
      color: C.brown
    }
  }, badge.copy)))));
}
function HeroPoster({
  badge
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "thhg-hero-card w-full max-w-sm",
    style: {
      background: C.cream,
      padding: 18,
      border: `1px solid ${C.tan}`,
      boxShadow: '0 24px 60px rgba(0,0,0,0.4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative p-8 text-center",
    style: {
      border: `2px double ${C.red}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald text-[10px] uppercase tracking-[0.32em]",
    style: {
      color: C.red
    }
  }, "EST. FOR APRIL \xB7 2024"), /*#__PURE__*/React.createElement(Rule, {
    color: C.red,
    className: "mt-3"
  }), /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye mt-5 text-3xl leading-[1]",
    style: {
      color: C.navy
    }
  }, badge.highlight), /*#__PURE__*/React.createElement("div", {
    className: "my-5"
  }, /*#__PURE__*/React.createElement(LogoMark, {
    size: 88
  })), /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye text-xl leading-tight",
    style: {
      color: C.red
    }
  }, badge.title), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-3 text-xs leading-6",
    style: {
      color: C.brown
    }
  }, badge.copy), /*#__PURE__*/React.createElement(Rule, {
    color: C.red,
    className: "mt-5"
  }), /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald mt-4 text-[10px] uppercase tracking-[0.25em]",
    style: {
      color: C.navy2
    }
  }, badge.eyebrow)));
}
function HeroPortrait({
  badge
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "thhg-hero-card relative w-full max-w-sm"
  }, /*#__PURE__*/React.createElement(Placeholder, {
    label: "APRIL \u2014 HERO PORTRAIT",
    aspect: "3/4",
    tone: "navy",
    className: "border-[6px]"
  }), /*#__PURE__*/React.createElement("div", {
    className: "absolute bottom-0 left-0 right-0 mx-4 -mb-6 p-5 text-center",
    style: {
      background: C.cream,
      border: `2px solid ${C.gold}`,
      boxShadow: '0 18px 40px rgba(0,0,0,0.3)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald text-[10px] uppercase tracking-[0.28em]",
    style: {
      color: C.red
    }
  }, badge.eyebrow), /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye mt-2 text-xl leading-tight",
    style: {
      color: C.navy2
    }
  }, badge.highlight)));
}

// ─── Expose globals ──────────────────────────────────────────────────────────
Object.assign(window, {
  C,
  LogoMark,
  Placeholder,
  StarRow,
  Marquee,
  Eyebrow,
  SectionHeader,
  Rule,
  CardGrid,
  StatCard,
  ScrollReveal,
  PageHero,
  useTweaks
});

/* ===== src/shell.jsx ===== */
// Site shell: sticky header, mobile nav, footer
// -----------------------------------------------------------------------------

const NAV_ITEMS = [{
  id: 'home',
  label: 'Home'
}, {
  id: 'our-story',
  label: 'Our Story'
}, {
  id: 'shop',
  label: 'Shop'
}, {
  id: 'apparel',
  label: 'Apparel'
}, {
  id: 'munchables',
  label: 'Munchables'
}, {
  id: 'lives-changed',
  label: 'Lives Changed'
}, {
  id: 'contact',
  label: 'Contact'
}];
function SiteShell({
  currentPage,
  navigate,
  children
}) {
  const [menuOpen, setMenuOpen] = React.useState(false);
  const go = React.useCallback(id => {
    navigate(id);
    setMenuOpen(false);
  }, [navigate]);
  return /*#__PURE__*/React.createElement("div", {
    className: "min-h-screen",
    style: {
      background: C.cream,
      color: C.ink
    }
  }, /*#__PURE__*/React.createElement("header", {
    className: "sticky top-0 z-40 backdrop-blur",
    style: {
      background: 'rgba(15,26,46,0.96)',
      borderBottom: `3px solid ${C.gold}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => go('home'),
    className: "flex items-center gap-3 text-left"
  }, /*#__PURE__*/React.createElement(LogoMark, {
    size: 44
  }), /*#__PURE__*/React.createElement("div", {
    className: "hidden sm:block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye text-sm sm:text-[15px]",
    style: {
      color: C.cream
    }
  }, "The Happy Hunting Grounds"), /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald mt-0.5 text-[10px] uppercase tracking-[0.28em]",
    style: {
      color: C.gold
    }
  }, "Good vibes save lives")), /*#__PURE__*/React.createElement("div", {
    className: "sm:hidden"
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye text-sm",
    style: {
      color: C.cream
    }
  }, "THHG"), /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald mt-0.5 text-[9px] uppercase tracking-[0.22em]",
    style: {
      color: C.gold
    }
  }, "Good vibes save lives"))), /*#__PURE__*/React.createElement("nav", {
    className: "hidden items-center gap-6 xl:flex",
    "aria-label": "Primary navigation"
  }, NAV_ITEMS.map(({
    id,
    label
  }) => /*#__PURE__*/React.createElement("button", {
    key: id,
    onClick: () => go(id),
    className: "thhg-oswald text-[12px] uppercase tracking-[0.18em] transition",
    style: {
      color: currentPage === id ? C.goldLt : C.cream
    }
  }, label))), /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 sm:gap-3"
  }, /*#__PURE__*/React.createElement("a", {
    href: "https://instagram.com/thehappyhuntinggrounds",
    target: "_blank",
    rel: "noopener noreferrer",
    "aria-label": "Instagram",
    title: "Instagram \u2014 follow along",
    className: "hidden sm:inline-flex h-10 w-10 items-center justify-center border transition hover:-translate-y-0.5",
    style: {
      borderColor: 'rgba(245,237,216,0.25)',
      color: C.cream
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "2",
    width: "20",
    height: "20",
    rx: "5",
    ry: "5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "17.5",
    y1: "6.5",
    x2: "17.51",
    y2: "6.5"
  }))), /*#__PURE__*/React.createElement("button", {
    onClick: () => go('shop'),
    className: "thhg-shine thhg-oswald px-3 py-2 text-[10px] font-semibold uppercase tracking-[0.18em] sm:px-4 sm:text-xs",
    style: {
      background: C.red,
      color: C.cream,
      border: `1px solid rgba(255,255,255,0.1)`
    }
  }, "Shop"), /*#__PURE__*/React.createElement("button", {
    onClick: () => setMenuOpen(v => !v),
    "aria-expanded": menuOpen,
    "aria-label": menuOpen ? 'Close menu' : 'Open menu',
    className: "xl:hidden flex flex-col justify-center gap-[5px] p-2"
  }, /*#__PURE__*/React.createElement("span", {
    className: `block h-0.5 w-6 origin-center transition-all ${menuOpen ? 'translate-y-[7px] rotate-45' : ''}`,
    style: {
      background: C.cream
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: `block h-0.5 w-6 transition-opacity ${menuOpen ? 'opacity-0' : ''}`,
    style: {
      background: C.cream
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: `block h-0.5 w-6 origin-center transition-all ${menuOpen ? '-translate-y-[7px] -rotate-45' : ''}`,
    style: {
      background: C.cream
    }
  })))), /*#__PURE__*/React.createElement("div", {
    className: `thhg-mobile-nav xl:hidden ${menuOpen ? 'open' : ''}`,
    style: {
      borderTop: '1px solid rgba(255,255,255,0.1)',
      background: C.navy
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("nav", {
    className: "mx-auto flex flex-col px-4 py-2 sm:px-6",
    "aria-label": "Mobile navigation"
  }, NAV_ITEMS.map(({
    id,
    label
  }) => /*#__PURE__*/React.createElement("button", {
    key: id,
    onClick: () => go(id),
    className: "thhg-oswald py-3 text-left text-sm uppercase tracking-[0.18em]",
    style: {
      color: currentPage === id ? C.goldLt : C.cream,
      borderBottom: '1px solid rgba(255,255,255,0.06)'
    }
  }, label)), /*#__PURE__*/React.createElement("a", {
    href: "https://instagram.com/thehappyhuntinggrounds",
    target: "_blank",
    rel: "noopener noreferrer",
    className: "thhg-oswald py-3 text-left text-sm uppercase tracking-[0.18em]",
    style: {
      color: C.gold
    }
  }, "Instagram \u2197"))))), /*#__PURE__*/React.createElement("main", {
    id: "main-content",
    "data-screen-label": currentPage
  }, children), /*#__PURE__*/React.createElement("footer", {
    className: "px-4 py-14 sm:px-6 lg:px-8",
    style: {
      background: C.navy,
      color: C.cream,
      borderTop: `3px solid ${C.gold}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto grid max-w-7xl gap-10 lg:grid-cols-[1.4fr_0.6fr_0.6fr]"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-4"
  }, /*#__PURE__*/React.createElement(LogoMark, {
    size: 64
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye text-2xl sm:text-3xl"
  }, "The Happy Hunting Grounds"), /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald mt-1 text-[11px] uppercase tracking-[0.28em]",
    style: {
      color: C.gold
    }
  }, "Good vibes save lives"))), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-5 max-w-xl text-sm leading-[1.85]",
    style: {
      color: '#E7D9BE'
    }
  }, "Built from rescue, healing, and second chances. Every purchase funds shelter dogs, supports veterans, and keeps April's spirit moving forward in the world.")), /*#__PURE__*/React.createElement("nav", {
    className: "content-start",
    "aria-label": "Footer navigation"
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald mb-4 text-[11px] uppercase tracking-[0.28em]",
    style: {
      color: C.gold
    }
  }, "Explore"), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-2 gap-3 lg:grid-cols-1"
  }, NAV_ITEMS.map(({
    id,
    label
  }) => /*#__PURE__*/React.createElement("button", {
    key: id,
    onClick: () => go(id),
    className: "thhg-oswald text-left text-xs uppercase tracking-[0.18em] transition hover:text-white",
    style: {
      color: C.tan
    }
  }, label)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald mb-4 text-[11px] uppercase tracking-[0.28em]",
    style: {
      color: C.gold
    }
  }, "Follow"), /*#__PURE__*/React.createElement("a", {
    href: "https://instagram.com/thehappyhuntinggrounds",
    target: "_blank",
    rel: "noopener noreferrer",
    className: "thhg-rye block text-xl transition hover:text-white",
    style: {
      color: C.cream
    }
  }, "@thehappyhuntinggrounds"), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-3 text-xs leading-6",
    style: {
      color: '#C8C0B0'
    }
  }, "Where we show exactly where the money goes \u2014 rescues, receipts, and stories in real time."))), /*#__PURE__*/React.createElement(Rule, {
    color: C.gold,
    className: "mx-auto mt-12 max-w-7xl opacity-40"
  }), /*#__PURE__*/React.createElement("div", {
    className: "mx-auto mt-6 flex max-w-7xl flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"
  }, /*#__PURE__*/React.createElement("p", {
    className: "thhg-oswald text-[11px] uppercase tracking-[0.2em]",
    style: {
      color: C.gold
    }
  }, "\xA9 ", new Date().getFullYear(), " The Happy Hunting Grounds \xB7 For April"), /*#__PURE__*/React.createElement("p", {
    className: "thhg-mono text-[10px] uppercase tracking-[0.2em]",
    style: {
      color: C.tan,
      opacity: 0.7
    }
  }, "Shop with purpose / Built with love"))));
}
Object.assign(window, {
  SiteShell,
  NAV_ITEMS
});

/* ===== src/page_home.jsx ===== */
// Home page
// -----------------------------------------------------------------------------

function HomePage({
  navigate
}) {
  const [email, setEmail] = React.useState('');
  const [joined, setJoined] = React.useState(false);
  const handleJoin = e => {
    e.preventDefault();
    if (email.trim()) setJoined(true);
  };
  const pillars = [{
    eyebrow: 'Pillar one',
    title: 'Rescue first',
    copy: 'A portion of every order funds shelter essentials — beds, enrichment toys, vet care, and foster support for dogs waiting on their second chance.',
    cta: 'See impact',
    onCta: () => navigate('lives-changed')
  }, {
    eyebrow: 'Pillar two',
    title: 'Healing through dogs',
    copy: 'Dogs heal people. Veterans. Grieving families. Survivors. Our mission actively supports programs that put dogs in the lives of people who need them most.',
    cta: 'Our story',
    onCta: () => navigate('our-story')
  }, {
    eyebrow: 'Pillar three',
    title: 'Full transparency',
    copy: 'Every dollar donated is documented. Every rescue spotlighted. Every bed sponsored is shown. We show the receipts because accountability is how real community is built.',
    cta: 'View updates',
    onCta: () => navigate('lives-changed')
  }];
  const shopCards = [{
    eyebrow: 'Apparel',
    title: 'Second Chance Collection',
    copy: 'Bold heritage-style pieces that carry the mission on their sleeve. Hoodies, tees, and caps for the tribe.',
    cta: 'Shop apparel',
    onCta: () => navigate('apparel'),
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "APPAREL LOOKBOOK",
      aspect: "4/5",
      tone: "navy"
    })
  }, {
    eyebrow: 'For the dogs',
    title: 'Munchables',
    copy: 'Single-ingredient, all-natural treats for good dogs everywhere. Made with intention. Sold with purpose.',
    cta: 'Shop treats',
    onCta: () => navigate('munchables'),
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "MUNCHABLES PACKAGING",
      aspect: "4/5",
      tone: "warm"
    })
  }, {
    eyebrow: 'Healing story',
    title: 'The THHG Book',
    copy: 'A story for every family who has loved and lost a dog. Written from the heart. Illustrated with warmth.',
    cta: 'View the book',
    onCta: () => navigate('shop'),
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "THE BOOK",
      aspect: "4/5",
      tone: "red"
    })
  }];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PageHero, {
    eyebrow: "Saving lives on both ends of the leash",
    title: "Built from love, loss, rescue, and a tribe that believes shopping should mean something.",
    subtitle: "The Happy Hunting Grounds is where second chances are celebrated, shelter dogs find voices, and every purchase does more than just arrive at your door.",
    badge: {
      title: 'Shop With Purpose',
      eyebrow: 'Brand promise',
      highlight: 'Good vibes save lives',
      copy: '25% minimum of every purchase goes directly back to rescue, shelter support, and veteran healing.'
    },
    cta: {
      label: 'Shop the mission',
      secondary: 'Read our story',
      onSecondary: () => navigate('our-story')
    },
    onCta: () => navigate('shop')
  }), /*#__PURE__*/React.createElement(Marquee, {
    items: ['Your vibe attracts your tribe', 'Second chances', 'Built on transparency', 'Community over clout', 'Good vibes save lives']
  }), /*#__PURE__*/React.createElement("section", {
    className: "py-16 sm:py-20 md:py-24",
    style: {
      background: C.creamLt
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto max-w-7xl px-5 sm:px-6 lg:px-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb-12 md:mb-14"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Why we exist",
    title: "A brand rooted in second chances.",
    copy: "We started because a dog named April changed everything \u2014 and losing her made us want to keep that love moving forward in the world."
  })), /*#__PURE__*/React.createElement(ScrollReveal, null, /*#__PURE__*/React.createElement(CardGrid, {
    items: pillars
  })))), /*#__PURE__*/React.createElement("section", {
    className: "py-16 sm:py-20",
    style: {
      background: C.cream
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto max-w-7xl px-5 sm:px-6 lg:px-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-14"
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative"
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald text-[11px] uppercase tracking-[0.28em]",
    style: {
      color: C.red
    }
  }, "\u2605 Our story in brief \u2605"), /*#__PURE__*/React.createElement("h2", {
    className: "thhg-rye mt-4 text-[34px] leading-[1.05] sm:text-[44px]",
    style: {
      color: C.navy2
    }
  }, "Before the brand,", /*#__PURE__*/React.createElement("br", null), "there was April."), /*#__PURE__*/React.createElement("div", {
    className: "mt-5 max-w-xs"
  }, /*#__PURE__*/React.createElement(Rule, {
    color: C.red
  })), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-6 text-[15px] leading-[1.85] sm:text-[17px]",
    style: {
      color: C.brown
    }
  }, "A rescue who healed a family \u2014 and built the soul of everything you see here. When she passed, the grief was real. So was the decision to honor her by helping other dogs, other families, and other people who needed exactly what she gave us."), /*#__PURE__*/React.createElement("blockquote", {
    className: "thhg-playfair mt-7 border-l-[3px] pl-5 text-[19px] italic leading-[1.6]",
    style: {
      color: C.navy2,
      borderColor: C.red
    }
  }, "\"We didn't build this to become a brand. We built it because the love was too big to stay quiet.\""), /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('our-story'),
    className: "thhg-oswald mt-7 inline-flex items-center gap-2 border-b-2 pb-1 text-xs font-semibold uppercase tracking-[0.24em]",
    style: {
      color: C.red,
      borderColor: C.red
    }
  }, "Read the full story \u2192")), /*#__PURE__*/React.createElement("div", {
    className: "grid gap-3 sm:grid-cols-6 sm:grid-rows-[180px_180px_180px]"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sm:col-span-4 sm:row-span-2"
  }, /*#__PURE__*/React.createElement(Placeholder, {
    label: "APRIL \u2014 RED RUFFLE",
    aspect: "auto",
    tone: "warm",
    className: "h-full min-h-[240px]"
  })), /*#__PURE__*/React.createElement("div", {
    className: "sm:col-span-2 sm:row-span-1"
  }, /*#__PURE__*/React.createElement(Placeholder, {
    label: "APRIL \u2014 RESTING",
    aspect: "auto",
    tone: "navy",
    className: "h-full min-h-[180px]"
  })), /*#__PURE__*/React.createElement("div", {
    className: "sm:col-span-2 sm:row-span-1"
  }, /*#__PURE__*/React.createElement(Placeholder, {
    label: "APRIL + FRANCO",
    aspect: "auto",
    tone: "red",
    className: "h-full min-h-[180px]"
  })), /*#__PURE__*/React.createElement("div", {
    className: "sm:col-span-6 sm:row-span-1 flex items-center justify-between gap-4 px-1"
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-mono text-[10px] uppercase tracking-[0.22em]",
    style: {
      color: C.brown,
      opacity: 0.7
    }
  }, "Photos \xB7 April 2019 \u2013 2023"), /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye text-sm",
    style: {
      color: C.red
    }
  }, "\u2605 \u2605 \u2605")))))), /*#__PURE__*/React.createElement("section", {
    className: "py-16 sm:py-20 md:py-24",
    style: {
      background: C.creamLt
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto max-w-7xl px-5 sm:px-6 lg:px-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb-10 flex flex-col gap-5 sm:mb-12 sm:flex-row sm:items-end sm:justify-between"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Shop with purpose",
    title: "Every product carries the mission."
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('shop'),
    className: "thhg-oswald shrink-0 self-start border-b-2 pb-1 text-[11px] font-semibold uppercase tracking-[0.24em]",
    style: {
      color: C.navy2,
      borderColor: C.navy2
    }
  }, "Browse all collections \u2192")), /*#__PURE__*/React.createElement(CardGrid, {
    items: shopCards
  }))), /*#__PURE__*/React.createElement("section", {
    className: "relative py-16 sm:py-20 md:py-24",
    style: {
      background: C.navy,
      color: C.cream
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pointer-events-none absolute inset-0 opacity-[0.06]",
    style: {
      backgroundImage: `radial-gradient(${C.cream} 1px, transparent 1px)`,
      backgroundSize: '24px 24px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "relative mx-auto max-w-7xl px-5 sm:px-6 lg:px-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb-10 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, {
    color: C.goldLt
  }, "Where the money goes"), /*#__PURE__*/React.createElement("h2", {
    className: "thhg-rye mt-4 text-3xl leading-[1.08] sm:text-4xl md:text-5xl",
    style: {
      color: C.cream
    }
  }, "Follow along \u2014 we show every dollar."), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-5 max-w-xl text-[15px] leading-[1.85]",
    style: {
      color: '#E7D9BE'
    }
  }, "Real rescues, real receipts. Instagram is where we document the day-to-day \u2014 beds funded, dogs spotlighted, families reunited. This is the accountability.")), /*#__PURE__*/React.createElement("a", {
    href: "https://instagram.com/thehappyhuntinggrounds",
    target: "_blank",
    rel: "noopener noreferrer",
    className: "thhg-shine thhg-oswald shrink-0 self-start border-2 px-5 py-3 text-xs font-semibold uppercase tracking-[0.22em] transition hover:-translate-y-0.5",
    style: {
      color: C.cream,
      borderColor: C.gold
    }
  }, "@thehappyhuntinggrounds \u2197")), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-6"
  }, [{
    label: 'BEDS FUNDED',
    tag: 'Q1'
  }, {
    label: 'RESCUE SPOTLIGHT',
    tag: 'LIVE'
  }, {
    label: 'MUNCHABLES DROP',
    tag: 'NEW'
  }, {
    label: 'VET CARE RECEIPT',
    tag: 'PROOF'
  }, {
    label: 'VETERAN PAIRING',
    tag: 'STORY'
  }, {
    label: 'SHELTER VISIT',
    tag: 'VLOG'
  }].map((p, i) => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: "https://instagram.com/thehappyhuntinggrounds",
    target: "_blank",
    rel: "noopener noreferrer",
    className: "thhg-card group relative aspect-square overflow-hidden"
  }, /*#__PURE__*/React.createElement(Placeholder, {
    label: p.label,
    aspect: "1/1",
    tone: i % 3 === 0 ? 'navy' : i % 3 === 1 ? 'red' : 'warm',
    className: "h-full"
  }), /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald absolute left-2 top-2 px-2 py-1 text-[9px] font-semibold uppercase tracking-[0.18em]",
    style: {
      background: C.gold,
      color: C.navy
    }
  }, p.tag)))))), /*#__PURE__*/React.createElement("section", {
    className: "py-16 sm:py-20",
    style: {
      background: C.navy2,
      color: C.cream,
      borderTop: `3px solid ${C.gold}`,
      borderBottom: `3px solid ${C.gold}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto max-w-7xl px-5 sm:px-6 lg:px-8"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Where it goes",
    title: "Your purchase does more than ship to your door.",
    titleColor: C.cream,
    eyebrowColor: C.goldLt,
    copy: "We document every donation, every rescue spotlight, every wobbler purchased and bed sponsored. You should know exactly what your support is doing in the world."
  }), /*#__PURE__*/React.createElement("div", {
    className: "mt-10 grid gap-6 sm:grid-cols-3"
  }, [{
    stat: 'Shelter beds',
    copy: 'Sponsored directly through product sales for dogs waiting on adoption.'
  }, {
    stat: 'Enrichment toys',
    copy: 'Wobblers and enrichment tools donated to keep shelter dogs mentally healthy.'
  }, {
    stat: 'Veteran support',
    copy: 'Programs connecting veterans with rescue dogs as part of healing-focused initiatives.'
  }].map(({
    stat,
    copy
  }) => /*#__PURE__*/React.createElement("div", {
    key: stat,
    className: "p-6",
    style: {
      border: '1px solid rgba(255,255,255,0.12)',
      background: 'rgba(255,255,255,0.04)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye text-2xl",
    style: {
      color: C.goldLt
    }
  }, "\u2605"), /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye mt-3 text-2xl",
    style: {
      color: C.cream
    }
  }, stat), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-3 text-sm leading-7",
    style: {
      color: '#C8C0B0'
    }
  }, copy)))), /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('lives-changed'),
    className: "thhg-shine thhg-oswald mt-10 border-2 px-6 py-3 text-sm font-semibold uppercase tracking-[0.18em] transition hover:-translate-y-0.5",
    style: {
      color: C.cream,
      borderColor: C.gold
    }
  }, "See the full impact \u2192"))), /*#__PURE__*/React.createElement("section", {
    className: "py-16 sm:py-20",
    style: {
      background: C.creamLt
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto max-w-5xl px-5 sm:px-6 lg:px-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "overflow-hidden border bg-white",
    style: {
      borderColor: C.tan,
      boxShadow: '0 20px 60px rgba(15,26,46,0.08)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "grid lg:grid-cols-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "p-8 sm:p-10",
    style: {
      background: C.cream,
      borderTop: `4px solid ${C.gold}`
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Stay connected"), /*#__PURE__*/React.createElement("h2", {
    className: "thhg-rye mt-4 text-3xl leading-tight sm:text-4xl",
    style: {
      color: C.navy2
    }
  }, "Join the pack."), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-4 text-sm leading-7",
    style: {
      color: C.brown
    }
  }, "Updates on new products, rescue spotlights, and what your purchases are actually doing in the world. No fluff. Just mission."), joined ? /*#__PURE__*/React.createElement("p", {
    className: "thhg-rye mt-8 text-2xl",
    style: {
      color: C.navy2
    }
  }, "Welcome to the pack. \u2605") : /*#__PURE__*/React.createElement("form", {
    onSubmit: handleJoin,
    className: "mt-8 flex flex-col gap-3 sm:flex-row"
  }, /*#__PURE__*/React.createElement("input", {
    type: "email",
    value: email,
    onChange: e => setEmail(e.target.value),
    placeholder: "Your email address",
    required: true,
    className: "thhg-baskerville min-w-0 flex-1 border bg-white px-5 py-3 text-sm outline-none",
    style: {
      borderColor: C.tan,
      color: C.ink
    }
  }), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    className: "thhg-oswald shrink-0 px-6 py-3 text-sm font-semibold uppercase tracking-[0.18em]",
    style: {
      background: C.red,
      color: C.cream
    }
  }, "Join the pack"))), /*#__PURE__*/React.createElement("div", {
    className: "p-8 sm:p-10",
    style: {
      background: C.navy,
      color: C.cream
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    color: C.goldLt
  }, "What you'll get"), /*#__PURE__*/React.createElement("ul", {
    className: "mt-6 space-y-5"
  }, ['New drop announcements before they go public.', 'Monthly rescue spotlights showing exactly where your support went.', 'Behind-the-scenes stories from the brand and the mission.', 'Early access to seasonal fundraising campaigns.'].map(item => /*#__PURE__*/React.createElement("li", {
    key: item,
    className: "flex gap-3"
  }, /*#__PURE__*/React.createElement("span", {
    className: "thhg-rye shrink-0",
    style: {
      color: C.gold
    }
  }, "\u2605"), /*#__PURE__*/React.createElement("span", {
    className: "thhg-baskerville text-sm leading-7",
    style: {
      color: '#E7D9BE'
    }
  }, item))))))))));
}
window.HomePage = HomePage;

/* ===== src/page_story.jsx ===== */
// Our Story — /why — business-card QR destination. DO NOT rename route.

function OurStoryPage({
  navigate
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PageHero, {
    eyebrow: "Our story",
    title: "Before the brand, there was a dog named April.",
    subtitle: "She came to us as a rescue, changed everything about how we saw the world, and left us with a mission we couldn't ignore. This is how love became a purpose.",
    badge: {
      title: 'Our Why',
      eyebrow: 'Built from purpose',
      highlight: 'From grief to good',
      copy: "The Happy Hunting Grounds is named after the place dogs go when they leave us — and built to honor them while they're still here."
    },
    cta: {
      label: 'Shop the mission',
      secondary: 'See lives changed',
      onSecondary: () => navigate('lives-changed')
    },
    onCta: () => navigate('shop')
  }), /*#__PURE__*/React.createElement(Marquee, {
    items: ['April', 'Healing', 'Rescue', 'Second chances', 'Good vibes save lives']
  }), /*#__PURE__*/React.createElement("section", {
    style: {
      background: C.navy
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "grid sm:grid-cols-3"
  }, [{
    label: 'APRIL — RED RUFFLE',
    tone: 'warm'
  }, {
    label: 'APRIL + FRANCO',
    tone: 'red'
  }, {
    label: 'APRIL AT REST',
    tone: 'navy'
  }].map((p, i) => /*#__PURE__*/React.createElement(Placeholder, {
    key: i,
    label: p.label,
    aspect: "1/1",
    tone: p.tone
  })))), /*#__PURE__*/React.createElement("section", {
    className: "py-16 sm:py-20 md:py-24",
    style: {
      background: C.creamLt
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto grid max-w-7xl gap-10 px-5 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:px-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "p-8 sm:p-10",
    style: {
      background: C.cream,
      borderTop: `4px solid ${C.gold}`,
      boxShadow: '0 20px 60px rgba(15,26,46,0.08)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "How it started",
    title: "Before the brand, there was love.",
    copy: "April was a rescue who came into a life that needed her. She gave companionship, healing, and joy in a season that needed all three. When she passed, the grief was real \u2014 but so was the clarity about what to do next."
  }), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-6 text-[15px] leading-[1.85]",
    style: {
      color: C.brown
    }
  }, "The Happy Hunting Grounds is named after the place dogs go when they leave us. Building this brand was a way to honor April by helping other dogs find the second chances she gave us. Every purchase, every product, every rescue spotlight carries her forward."), /*#__PURE__*/React.createElement("blockquote", {
    className: "thhg-playfair mt-7 border-l-[3px] pl-5 text-[19px] italic leading-[1.6]",
    style: {
      color: C.navy2,
      borderColor: C.red
    }
  }, "\"We didn't build this to become a brand. We built it because the love was too big to stay quiet.\""), /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('shop'),
    className: "thhg-oswald mt-7 inline-flex items-center gap-2 border-b-2 pb-1 text-xs font-semibold uppercase tracking-[0.24em]",
    style: {
      color: C.red,
      borderColor: C.red
    }
  }, "Shop with purpose \u2192")), /*#__PURE__*/React.createElement("div", {
    className: "grid content-start gap-4"
  }, [{
    value: 'April',
    label: 'The heart behind the name'
  }, {
    value: 'Rescue',
    label: 'Every dog deserves a second chance'
  }, {
    value: 'Healing',
    label: 'Dogs heal people. Always have.'
  }, {
    value: 'Community',
    label: 'Your tribe is already here'
  }].map(({
    value,
    label
  }) => /*#__PURE__*/React.createElement("div", {
    key: label,
    className: "p-6",
    style: {
      background: '#fff',
      border: `1px solid ${C.tan}`,
      boxShadow: '0 10px 30px rgba(15,26,46,0.05)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye text-3xl",
    style: {
      color: C.red
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald mt-2 text-xs uppercase tracking-[0.2em]",
    style: {
      color: C.brown
    }
  }, label)))))), /*#__PURE__*/React.createElement("section", {
    className: "py-16 sm:py-20",
    style: {
      background: C.cream
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto max-w-7xl px-5 sm:px-6 lg:px-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb-10"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Three chapters",
    title: "Love. Loss. Purpose.",
    align: "center"
  })), /*#__PURE__*/React.createElement(CardGrid, {
    items: [{
      eyebrow: 'Chapter one',
      title: 'Love',
      copy: "April arrived as a rescue and stayed as the foundation of everything. She showed what a second chance can become when someone decides to show up.",
      media: /*#__PURE__*/React.createElement(Placeholder, {
        label: "CH. 1 \u2014 LOVE",
        aspect: "4/3",
        tone: "warm"
      })
    }, {
      eyebrow: 'Chapter two',
      title: 'Loss',
      copy: "When April passed, the grief was the kind that doesn't leave. But grief rooted in real love has direction — and this brand is the direction ours took.",
      media: /*#__PURE__*/React.createElement(Placeholder, {
        label: "CH. 2 \u2014 LOSS",
        aspect: "4/3",
        tone: "navy"
      })
    }, {
      eyebrow: 'Chapter three',
      title: 'Purpose',
      copy: "The mission became the answer to loss: help more dogs, support more rescues, and fund the kind of healing that only dogs can give.",
      media: /*#__PURE__*/React.createElement(Placeholder, {
        label: "CH. 3 \u2014 PURPOSE",
        aspect: "4/3",
        tone: "red"
      })
    }]
  }))));
}
window.OurStoryPage = OurStoryPage;

/* ===== src/page_shop.jsx ===== */
function ShopPage({
  navigate
}) {
  const collections = [{
    eyebrow: 'Apparel',
    title: 'Second Chance Collection',
    copy: 'Heritage-style hoodies, tees, and caps that carry the mission on their sleeve.',
    cta: 'View collection',
    onCta: () => navigate('apparel'),
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "APPAREL",
      aspect: "4/5",
      tone: "navy"
    })
  }, {
    eyebrow: 'Treats',
    title: 'Munchables',
    copy: 'Single-ingredient, all-natural treats for good dogs. Made with care. Sold with purpose.',
    cta: 'Shop treats',
    onCta: () => navigate('munchables'),
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "MUNCHABLES",
      aspect: "4/5",
      tone: "warm"
    })
  }, {
    eyebrow: 'Story',
    title: 'The THHG Book',
    copy: 'A story written for every family who has loved and lost a dog. Warm, honest, illustrated with heart.',
    cta: 'View the book',
    onCta: () => navigate('our-story'),
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "THE BOOK",
      aspect: "4/5",
      tone: "red"
    })
  }, {
    eyebrow: 'Mission',
    title: 'Rescue Taws',
    copy: 'A product line built to let people support shelter enrichment while getting something meaningful.',
    cta: 'Explore',
    onCta: () => navigate('shop'),
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "RESCUE TAWS",
      aspect: "4/5",
      tone: "navy"
    })
  }, {
    eyebrow: 'Seasonal',
    title: 'Featured Donations',
    copy: 'Seasonal fundraising for urgent shelter needs — wobblers, beds, vet care, and more.',
    cta: 'Support now',
    onCta: () => navigate('lives-changed'),
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "SEASONAL DRIVE",
      aspect: "4/5",
      tone: "red"
    })
  }, {
    eyebrow: 'Bundles',
    title: 'Gift With Purpose',
    copy: 'Packages built for gift-givers who want their purchase to do more than just wrap nicely.',
    cta: 'See bundles',
    onCta: () => navigate('shop'),
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "GIFT BUNDLES",
      aspect: "4/5",
      tone: "warm"
    })
  }];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PageHero, {
    eyebrow: "Shop with purpose",
    title: "Every product carries the mission forward.",
    subtitle: "Six collections. One mission. Whether you're shopping for yourself, a dog, or someone who loves both \u2014 every purchase here goes further than most.",
    badge: {
      title: 'The Shop',
      eyebrow: 'Storefront',
      highlight: 'Purpose in every order',
      copy: '25% minimum of every sale goes back to rescue, shelter support, and healing-focused programs.'
    }
  }), /*#__PURE__*/React.createElement(Marquee, {
    items: ['Apparel', 'Treats', 'Books', 'Bundles', 'Mission-driven'],
    tone: "red"
  }), /*#__PURE__*/React.createElement("section", {
    className: "py-16 sm:py-20 md:py-24",
    style: {
      background: C.cream
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto max-w-7xl px-5 sm:px-6 lg:px-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb-10 md:mb-12"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "All collections",
    title: "Shop by what moves you.",
    copy: "From apparel to treats to the book that started it all \u2014 every collection is built around the mission."
  })), /*#__PURE__*/React.createElement(CardGrid, {
    items: collections
  }))));
}
window.ShopPage = ShopPage;

/* ===== src/page_apparel.jsx ===== */
function ApparelPage({
  navigate
}) {
  const products = [{
    eyebrow: 'Best seller',
    title: 'Good Vibes Save Lives Tee',
    copy: 'The signature line, on the signature piece. Heavyweight cotton, vintage-washed feel, and a message the whole tribe can wear.',
    cta: 'Choose options',
    onCta: () => {},
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "GVSL TEE",
      aspect: "1/1",
      tone: "warm"
    })
  }, {
    eyebrow: 'Best seller',
    title: 'Your Vibe Attracts Your Tribe Hoodie',
    copy: 'The flagship pullover. Built for the person who finds their people through what they believe, not just where they live.',
    cta: 'Choose options',
    onCta: () => {},
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "TRIBE HOODIE",
      aspect: "1/1",
      tone: "navy"
    })
  }, {
    eyebrow: 'Best seller',
    title: 'Second Chances Hat',
    copy: 'A clean, mission-forward cap that carries the brand without saying everything at once.',
    cta: 'Choose options',
    onCta: () => {},
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "TRIBE CAP",
      aspect: "1/1",
      tone: "red"
    })
  }, {
    eyebrow: 'New',
    title: 'April Memorial Longsleeve',
    copy: 'Limited drop. Printed with love, in her honor. A portion supports shelter enrichment programs.',
    cta: 'Choose options',
    onCta: () => {},
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "APRIL LONGSLEEVE",
      aspect: "1/1",
      tone: "navy"
    })
  }, {
    eyebrow: 'Coming soon',
    title: 'Rescue Crewneck',
    copy: 'Heavyweight fleece, heritage-inspired graphics, and the tribe feeling built right in.',
    cta: 'Notify me',
    onCta: () => {},
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "RESCUE CREW",
      aspect: "1/1",
      tone: "warm"
    })
  }, {
    eyebrow: 'Accessory',
    title: 'Tribe Patch Set',
    copy: 'Iron-on patches for jackets, bags, or anything that needs a little more mission on it.',
    cta: 'Add to cart',
    onCta: () => {},
    media: /*#__PURE__*/React.createElement(Placeholder, {
      label: "PATCH SET",
      aspect: "1/1",
      tone: "red"
    })
  }];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PageHero, {
    eyebrow: "Second Chance Apparel",
    title: "Wear the mission. Build the tribe.",
    subtitle: "Heritage-inspired pieces that feel like the culture behind them. Bold, built to last, and rooted in a story worth wearing.",
    badge: {
      title: 'Apparel',
      eyebrow: 'Wear the mission',
      highlight: 'Second Chance Collection',
      copy: 'Every piece carries the brand voice, the vintage styling, and a portion goes back to rescue.'
    }
  }), /*#__PURE__*/React.createElement(Marquee, {
    items: ['Wear the mission', 'Second Chance Collection', 'Built to last', 'Good vibes save lives']
  }), /*#__PURE__*/React.createElement("section", {
    className: "py-16 sm:py-20 md:py-24",
    style: {
      background: C.creamLt
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto max-w-7xl px-5 sm:px-6 lg:px-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb-10"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Current drop",
    title: "Merch built for the tribe.",
    copy: "These aren't just shirts. They're a statement \u2014 second chances, real community, and good vibes that actually save lives."
  })), /*#__PURE__*/React.createElement(CardGrid, {
    items: products
  }))));
}
window.ApparelPage = ApparelPage;

/* ===== src/page_munchables.jsx ===== */
const MUNCHABLES_LINE = [{
  name: 'Quackers',
  ingredient: 'Duck',
  copy: 'Single-ingredient duck bites. High-protein, grain-free, and something your dog will absolutely lose their mind over.',
  tags: ['High protein', 'Grain-free', 'Novel protein'],
  price: '$14'
}, {
  name: 'Cluckers',
  ingredient: 'Chicken',
  copy: 'Classic chicken strips, nothing else. The everyday treat that never gets old, from dogs who deserve the real thing.',
  tags: ['Lean protein', 'Digestible', 'All ages'],
  price: '$12'
}, {
  name: 'Gobbler',
  ingredient: 'Turkey',
  copy: 'Low-fat turkey bites perfect for training, rewarding, or just because your dog had a really good day.',
  tags: ['Low fat', 'Training treat', 'Sensitive stomachs'],
  price: '$13'
}, {
  name: 'Mooers',
  ingredient: 'Beef',
  copy: 'Beef lung bites — chewy, satisfying, and packed with the nutrition that keeps tails wagging hard.',
  tags: ['Chewy', 'Rich flavor', 'High value reward'],
  price: '$14'
}, {
  name: 'Swimmer',
  ingredient: 'Salmon',
  copy: 'Omega-3 packed salmon treats for coat health, brain function, and dogs who appreciate something from the deep end.',
  tags: ['Omega-3', 'Coat health', 'Brain support'],
  price: '$15'
}, {
  name: 'Rooters',
  ingredient: 'Sweet Potato',
  copy: 'Plant-based sweet potato chews for dogs with sensitivities or owners who want a clean vegetarian option.',
  tags: ['Vegetarian', 'Sensitivity-friendly', 'Fiber rich'],
  price: '$11'
}];
function MunchablesPage() {
  const [qtys, setQtys] = React.useState(() => Object.fromEntries(MUNCHABLES_LINE.map(p => [p.name, 1])));
  const [cart, setCart] = React.useState(0);
  const [added, setAdded] = React.useState(null);
  const adjustQty = (name, fn) => setQtys(p => ({
    ...p,
    [name]: fn(p[name])
  }));
  const addToCart = name => {
    setCart(c => c + qtys[name]);
    setAdded(name);
    setTimeout(() => setAdded(null), 1400);
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PageHero, {
    eyebrow: "Munchables by THHG",
    title: "The complete treat line. One ingredient. Zero compromise.",
    subtitle: "Six flavors. All-natural, single-ingredient treats made for good dogs and owners who read the label. Every bag sold puts 25% back into rescue.",
    badge: {
      title: 'Munchables',
      eyebrow: 'The treat line',
      highlight: 'Single ingredient',
      copy: 'Duck, chicken, turkey, beef, salmon, sweet potato. Nothing else. Ever.'
    }
  }), /*#__PURE__*/React.createElement(Marquee, {
    items: ['Quackers', 'Cluckers', 'Gobbler', 'Mooers', 'Swimmer', 'Rooters', 'Single ingredient always']
  }), cart > 0 && /*#__PURE__*/React.createElement("div", {
    className: "sticky top-[68px] z-30 py-2.5 text-center",
    style: {
      background: C.gold,
      color: C.navy,
      borderBottom: `2px solid ${C.red}`
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "thhg-oswald text-xs uppercase tracking-[0.22em]"
  }, "\u2605 ", cart, " bag", cart > 1 ? 's' : '', " in your cart \u2605")), /*#__PURE__*/React.createElement("section", {
    className: "py-16 sm:py-20 md:py-24",
    style: {
      background: C.cream
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto max-w-7xl px-5 sm:px-6 lg:px-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb-10"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "The full line",
    title: "Six flavors. All good dogs qualify.",
    copy: "Every Munchables treat is one ingredient \u2014 nothing added, nothing hidden. Sourced with the same intention that drives everything we make."
  })), /*#__PURE__*/React.createElement("div", {
    className: "grid gap-5 sm:gap-6 sm:grid-cols-2 lg:grid-cols-3"
  }, MUNCHABLES_LINE.map(({
    name,
    ingredient,
    copy,
    tags,
    price
  }) => /*#__PURE__*/React.createElement("article", {
    key: name,
    className: "thhg-card overflow-hidden border bg-white",
    style: {
      borderColor: C.tan,
      boxShadow: '0 14px 40px rgba(15,26,46,0.07)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative",
    style: {
      borderBottom: `3px solid ${C.gold}`
    }
  }, /*#__PURE__*/React.createElement(Placeholder, {
    label: `${name.toUpperCase()} — ${ingredient.toUpperCase()}`,
    aspect: "4/3",
    tone: ingredient === 'Sweet Potato' ? 'warm' : ingredient === 'Beef' || ingredient === 'Salmon' ? 'red' : 'navy'
  }), /*#__PURE__*/React.createElement("div", {
    className: "absolute right-3 top-3 thhg-oswald px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.18em]",
    style: {
      background: C.cream,
      color: C.navy
    }
  }, price)), /*#__PURE__*/React.createElement("div", {
    className: "p-5 sm:p-6"
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald text-[10px] uppercase tracking-[0.25em]",
    style: {
      color: C.red
    }
  }, ingredient), /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye mt-1 text-2xl",
    style: {
      color: C.navy2
    }
  }, name), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-3 text-sm leading-7",
    style: {
      color: C.brown
    }
  }, copy), /*#__PURE__*/React.createElement("div", {
    className: "mt-4 flex flex-wrap gap-2"
  }, tags.map(t => /*#__PURE__*/React.createElement("span", {
    key: t,
    className: "thhg-oswald px-2 py-1 text-[10px] uppercase tracking-[0.14em]",
    style: {
      border: `1px solid ${C.tan}`,
      color: C.brown
    }
  }, t))), /*#__PURE__*/React.createElement("div", {
    className: "mt-5 flex items-center gap-3"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center",
    style: {
      border: `1px solid ${C.tan}`
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => adjustQty(name, q => Math.max(1, q - 1)),
    "aria-label": `Decrease ${name}`,
    className: "thhg-oswald px-3 py-2",
    style: {
      color: C.navy2
    }
  }, "\u2212"), /*#__PURE__*/React.createElement("span", {
    className: "thhg-oswald min-w-[2rem] px-2 py-2 text-center text-sm",
    style: {
      color: C.navy2
    }
  }, qtys[name]), /*#__PURE__*/React.createElement("button", {
    onClick: () => adjustQty(name, q => q + 1),
    "aria-label": `Increase ${name}`,
    className: "thhg-oswald px-3 py-2",
    style: {
      color: C.navy2
    }
  }, "+")), /*#__PURE__*/React.createElement("button", {
    onClick: () => addToCart(name),
    className: "thhg-shine thhg-oswald flex-1 py-2.5 text-xs font-semibold uppercase tracking-[0.18em] transition",
    style: {
      background: added === name ? C.gold : C.red,
      color: added === name ? C.navy : C.cream
    }
  }, added === name ? '★ Added ★' : 'Add to cart')))))), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-10 text-center text-xs",
    style: {
      color: C.brown
    }
  }, "\u2605 25% of every Munchables purchase goes directly to shelter dog support programs."))));
}
window.MunchablesPage = MunchablesPage;

/* ===== src/page_lives.jsx ===== */
const DONATION_LOG = [{
  period: 'Q1 2024',
  item: '12 shelter beds',
  org: 'Local rescue partners',
  detail: 'Sponsored comfort bedding for 12 dogs in active foster care, funded through Second Chance Apparel sales.'
}, {
  period: 'Q4 2023',
  item: '8 enrichment toys',
  org: 'County animal shelter',
  detail: 'Wobbler-style enrichment tools donated to reduce stress in long-stay shelter dogs during the holiday surge.'
}, {
  period: 'Q3 2023',
  item: 'Emergency vet fund',
  org: 'Independent rescue',
  detail: 'Contributed to emergency medical care for a dog pulled from an urgent euthanasia situation.'
}];
const INSTA_POSTS = [{
  label: 'SHELTER BEDS — Q1',
  tag: 'PROOF'
}, {
  label: 'QUACKERS RESTOCK',
  tag: 'NEW'
}, {
  label: 'FOR APRIL',
  tag: 'STORY'
}, {
  label: 'GOOD VIBES',
  tag: 'VLOG'
}, {
  label: 'RESCUE SPOTLIGHT',
  tag: 'LIVE'
}, {
  label: 'SECOND CHANCE',
  tag: 'DROP'
}];
function LivesChangedPage({
  navigate
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PageHero, {
    eyebrow: "Lives changed",
    title: "Your support documented. No vague promises.",
    subtitle: "Every donation this brand makes is logged and shared here. Dogs helped. Beds funded. Treatments covered. This is the proof of mission.",
    badge: {
      title: 'Lives Changed',
      eyebrow: 'Proof of impact',
      highlight: 'Show the receipts',
      copy: 'Accountability is how a mission-driven brand earns real trust. We document everything.'
    }
  }), /*#__PURE__*/React.createElement(Marquee, {
    items: ['Beds funded', 'Enrichment donated', 'Rescue support', 'Vet care', 'Show the receipts']
  }), /*#__PURE__*/React.createElement("section", {
    className: "py-16 sm:py-20 md:py-24",
    style: {
      background: C.creamLt
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto max-w-7xl px-5 sm:px-6 lg:px-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb-10 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Donation log",
    title: "Where your money actually went.",
    copy: "Updated quarterly. Every entry is a real donation tied to a real product sale."
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('shop'),
    className: "thhg-oswald shrink-0 self-start border-b-2 pb-1 text-[11px] font-semibold uppercase tracking-[0.24em]",
    style: {
      color: C.navy2,
      borderColor: C.navy2
    }
  }, "Shop to add more \u2192")), /*#__PURE__*/React.createElement("div", {
    className: "grid gap-6"
  }, DONATION_LOG.map(({
    period,
    item,
    org,
    detail
  }) => /*#__PURE__*/React.createElement("div", {
    key: period,
    className: "grid overflow-hidden sm:grid-cols-[220px_1fr]",
    style: {
      background: '#fff',
      border: `1px solid ${C.tan}`,
      boxShadow: '0 10px 30px rgba(15,26,46,0.05)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "p-6",
    style: {
      background: `linear-gradient(160deg, ${C.navy}, ${C.navy2})`
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald text-[10px] uppercase tracking-[0.22em]",
    style: {
      color: C.goldLt
    }
  }, "Period"), /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye mt-2 text-xl",
    style: {
      color: C.cream
    }
  }, period), /*#__PURE__*/React.createElement(StarRow, {
    color: C.gold,
    size: "text-xs"
  })), /*#__PURE__*/React.createElement("div", {
    className: "p-6"
  }, /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye text-2xl",
    style: {
      color: C.navy2
    }
  }, item), /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald mt-1 text-xs uppercase tracking-[0.18em]",
    style: {
      color: C.red
    }
  }, org), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-3 text-sm leading-7",
    style: {
      color: C.brown
    }
  }, detail))))))), /*#__PURE__*/React.createElement("section", {
    className: "py-16 sm:py-20",
    style: {
      background: C.cream
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto max-w-7xl px-5 sm:px-6 lg:px-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb-10"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Where your support lands",
    title: "Three places every dollar flows.",
    align: "center"
  })), /*#__PURE__*/React.createElement(CardGrid, {
    items: [{
      eyebrow: 'What we fund',
      title: 'Shelter essentials',
      copy: 'Beds, blankets, enrichment toys, and comfort items for dogs in active shelter care while they wait for their homes.',
      cta: 'Support now',
      onCta: () => navigate('shop'),
      media: /*#__PURE__*/React.createElement(Placeholder, {
        label: "SHELTER ESSENTIALS",
        aspect: "4/3",
        tone: "warm"
      })
    }, {
      eyebrow: 'What we fund',
      title: 'Emergency vet care',
      copy: 'When rescue partners pull dogs from urgent situations, we contribute to immediate veterinary needs.',
      cta: 'Support now',
      onCta: () => navigate('shop'),
      media: /*#__PURE__*/React.createElement(Placeholder, {
        label: "VET CARE",
        aspect: "4/3",
        tone: "red"
      })
    }, {
      eyebrow: 'What we fund',
      title: 'Veteran programs',
      copy: 'Dog-assisted healing programs for veterans. Because dogs heal people — and that healing is worth funding.',
      cta: 'Support now',
      onCta: () => navigate('shop'),
      media: /*#__PURE__*/React.createElement(Placeholder, {
        label: "VETERAN HEALING",
        aspect: "4/3",
        tone: "navy"
      })
    }]
  }))), /*#__PURE__*/React.createElement("section", {
    className: "relative py-16 sm:py-20 md:py-24",
    style: {
      background: C.navy,
      color: C.cream
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pointer-events-none absolute inset-0 opacity-[0.06]",
    style: {
      backgroundImage: `radial-gradient(${C.cream} 1px, transparent 1px)`,
      backgroundSize: '24px 24px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "relative mx-auto max-w-7xl px-5 sm:px-6 lg:px-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb-10 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, {
    color: C.goldLt
  }, "Follow along"), /*#__PURE__*/React.createElement("h2", {
    className: "thhg-rye mt-4 text-3xl sm:text-4xl md:text-5xl",
    style: {
      color: C.cream
    }
  }, "@thehappyhuntinggrounds"), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-4 max-w-xl text-[15px] leading-[1.85]",
    style: {
      color: '#E7D9BE'
    }
  }, "This is where the receipts live \u2014 posted the moment every bed gets funded, every dog gets spotlighted, every receipt comes in.")), /*#__PURE__*/React.createElement("a", {
    href: "https://instagram.com/thehappyhuntinggrounds",
    target: "_blank",
    rel: "noopener noreferrer",
    className: "thhg-shine thhg-oswald shrink-0 self-start border-2 px-5 py-3 text-xs font-semibold uppercase tracking-[0.22em]",
    style: {
      color: C.cream,
      borderColor: C.gold
    }
  }, "Follow on Instagram \u2197")), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6"
  }, INSTA_POSTS.map((p, i) => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: "https://instagram.com/thehappyhuntinggrounds",
    target: "_blank",
    rel: "noopener noreferrer",
    className: "thhg-card relative block aspect-square overflow-hidden"
  }, /*#__PURE__*/React.createElement(Placeholder, {
    label: p.label,
    aspect: "1/1",
    tone: i % 3 === 0 ? 'navy' : i % 3 === 1 ? 'red' : 'warm',
    className: "h-full"
  }), /*#__PURE__*/React.createElement("div", {
    className: "thhg-oswald absolute left-2 top-2 px-2 py-1 text-[9px] font-semibold uppercase tracking-[0.18em]",
    style: {
      background: C.gold,
      color: C.navy
    }
  }, p.tag)))))));
}
window.LivesChangedPage = LivesChangedPage;

/* ===== src/page_contact.jsx ===== */
function ContactPage() {
  const [form, setForm] = React.useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [sent, setSent] = React.useState(false);
  const update = field => e => setForm(f => ({
    ...f,
    [field]: e.target.value
  }));
  const handleSubmit = e => {
    e.preventDefault();
    setSent(true);
  };
  const inputStyle = {
    border: `1px solid ${C.tan}`,
    background: '#fff',
    color: C.ink
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PageHero, {
    eyebrow: "Contact",
    title: "Say hello. Share a rescue. Start a conversation.",
    subtitle: "Press, partnerships, rescue stories, wholesale, or just a note to say thanks \u2014 this inbox is read by real humans who care about the mission.",
    badge: {
      title: 'Contact',
      eyebrow: 'Get in touch',
      highlight: "Let's talk",
      copy: 'Every message lands directly with the team. We read every single one.'
    }
  }), /*#__PURE__*/React.createElement("section", {
    className: "py-16 sm:py-20 md:py-24",
    style: {
      background: C.cream
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mx-auto grid max-w-6xl gap-8 px-5 sm:px-6 lg:grid-cols-[1.2fr_0.8fr] lg:px-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "p-8 sm:p-10",
    style: {
      background: '#fff',
      border: `1px solid ${C.tan}`,
      boxShadow: '0 14px 40px rgba(15,26,46,0.07)',
      borderTop: `4px solid ${C.gold}`
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Drop a note",
    title: "Tell us what's on your mind."
  }), sent ? /*#__PURE__*/React.createElement("div", {
    className: "mt-8 p-6",
    style: {
      background: C.cream,
      border: `1px dashed ${C.red}`
    }
  }, /*#__PURE__*/React.createElement(StarRow, {
    color: C.red
  }), /*#__PURE__*/React.createElement("h3", {
    className: "thhg-rye mt-3 text-2xl",
    style: {
      color: C.navy2
    }
  }, "Message received."), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-2 text-sm leading-7",
    style: {
      color: C.brown
    }
  }, "Thanks for reaching out. We'll be in touch soon \u2014 usually within a day or two.")) : /*#__PURE__*/React.createElement("form", {
    onSubmit: handleSubmit,
    className: "mt-8 grid gap-4"
  }, /*#__PURE__*/React.createElement("div", {
    className: "grid gap-4 sm:grid-cols-2"
  }, /*#__PURE__*/React.createElement("label", {
    className: "block"
  }, /*#__PURE__*/React.createElement("span", {
    className: "thhg-oswald text-[10px] uppercase tracking-[0.22em]",
    style: {
      color: C.brown
    }
  }, "Name"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    required: true,
    value: form.name,
    onChange: update('name'),
    className: "thhg-baskerville mt-2 w-full px-4 py-3 text-sm outline-none",
    style: inputStyle
  })), /*#__PURE__*/React.createElement("label", {
    className: "block"
  }, /*#__PURE__*/React.createElement("span", {
    className: "thhg-oswald text-[10px] uppercase tracking-[0.22em]",
    style: {
      color: C.brown
    }
  }, "Email"), /*#__PURE__*/React.createElement("input", {
    type: "email",
    required: true,
    value: form.email,
    onChange: update('email'),
    className: "thhg-baskerville mt-2 w-full px-4 py-3 text-sm outline-none",
    style: inputStyle
  }))), /*#__PURE__*/React.createElement("label", {
    className: "block"
  }, /*#__PURE__*/React.createElement("span", {
    className: "thhg-oswald text-[10px] uppercase tracking-[0.22em]",
    style: {
      color: C.brown
    }
  }, "Subject"), /*#__PURE__*/React.createElement("select", {
    value: form.subject,
    onChange: update('subject'),
    className: "thhg-baskerville mt-2 w-full px-4 py-3 text-sm outline-none",
    style: inputStyle
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "Select a topic\u2026"), /*#__PURE__*/React.createElement("option", null, "Rescue story / spotlight"), /*#__PURE__*/React.createElement("option", null, "Press & media"), /*#__PURE__*/React.createElement("option", null, "Wholesale & partnerships"), /*#__PURE__*/React.createElement("option", null, "Product question"), /*#__PURE__*/React.createElement("option", null, "Just saying hi"))), /*#__PURE__*/React.createElement("label", {
    className: "block"
  }, /*#__PURE__*/React.createElement("span", {
    className: "thhg-oswald text-[10px] uppercase tracking-[0.22em]",
    style: {
      color: C.brown
    }
  }, "Message"), /*#__PURE__*/React.createElement("textarea", {
    required: true,
    rows: 5,
    value: form.message,
    onChange: update('message'),
    className: "thhg-baskerville mt-2 w-full px-4 py-3 text-sm outline-none",
    style: inputStyle
  })), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    className: "thhg-shine thhg-oswald mt-2 self-start px-6 py-3 text-xs font-semibold uppercase tracking-[0.22em]",
    style: {
      background: C.red,
      color: C.cream
    }
  }, "Send message \u2192"))), /*#__PURE__*/React.createElement("div", {
    className: "grid content-start gap-5"
  }, /*#__PURE__*/React.createElement("div", {
    className: "p-6",
    style: {
      background: C.navy,
      color: C.cream
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    color: C.goldLt
  }, "Email"), /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye mt-3 text-2xl"
  }, "hello@thehappyhuntinggrounds.org"), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-3 text-sm leading-7",
    style: {
      color: '#E7D9BE'
    }
  }, "We read everything. Expect a real reply.")), /*#__PURE__*/React.createElement("div", {
    className: "p-6",
    style: {
      background: '#fff',
      border: `1px solid ${C.tan}`
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Instagram"), /*#__PURE__*/React.createElement("a", {
    href: "https://instagram.com/thehappyhuntinggrounds",
    target: "_blank",
    rel: "noopener noreferrer",
    className: "thhg-rye mt-3 block text-2xl",
    style: {
      color: C.navy2
    }
  }, "@thehappyhuntinggrounds"), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-3 text-sm leading-7",
    style: {
      color: C.brown
    }
  }, "DMs are open for rescue stories and spotlights.")), /*#__PURE__*/React.createElement("div", {
    className: "p-6",
    style: {
      background: C.cream,
      border: `1px solid ${C.tan}`
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Partnerships"), /*#__PURE__*/React.createElement("div", {
    className: "thhg-rye mt-3 text-xl",
    style: {
      color: C.navy2
    }
  }, "Rescues. Shelters. Veteran orgs."), /*#__PURE__*/React.createElement("p", {
    className: "thhg-baskerville mt-3 text-sm leading-7",
    style: {
      color: C.brown
    }
  }, "We're always looking for mission-aligned partners. Pitch us \u2014 we'll listen."))))));
}
window.ContactPage = ContactPage;

/* ===== src/app.jsx ===== */
// Router & mount

const PAGES = {
  'home': nav => /*#__PURE__*/React.createElement(HomePage, {
    navigate: nav
  }),
  'our-story': nav => /*#__PURE__*/React.createElement(OurStoryPage, {
    navigate: nav
  }),
  'why': nav => /*#__PURE__*/React.createElement(OurStoryPage, {
    navigate: nav
  }),
  // business-card QR alias
  'shop': nav => /*#__PURE__*/React.createElement(ShopPage, {
    navigate: nav
  }),
  'apparel': nav => /*#__PURE__*/React.createElement(ApparelPage, {
    navigate: nav
  }),
  'munchables': nav => /*#__PURE__*/React.createElement(MunchablesPage, {
    navigate: nav
  }),
  'lives-changed': nav => /*#__PURE__*/React.createElement(LivesChangedPage, {
    navigate: nav
  }),
  'contact': nav => /*#__PURE__*/React.createElement(ContactPage, {
    navigate: nav
  })
};
function THHGWebsite() {
  // Persist page to localStorage + hash
  const initial = (() => {
    const hash = window.location.hash.replace('#', '');
    if (hash && PAGES[hash]) return hash;
    const saved = localStorage.getItem('thhg-page');
    if (saved && PAGES[saved]) return saved;
    return 'home';
  })();
  const [currentPage, setCurrentPage] = React.useState(initial);
  const navigate = React.useCallback(id => {
    const target = PAGES[id] ? id : 'home';
    setCurrentPage(target);
    localStorage.setItem('thhg-page', target);
    window.location.hash = target;
  }, []);
  React.useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: 'instant'
    });
  }, [currentPage]);
  React.useEffect(() => {
    const onHash = () => {
      const h = window.location.hash.replace('#', '');
      if (h && PAGES[h] && h !== currentPage) setCurrentPage(h);
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, [currentPage]);
  return /*#__PURE__*/React.createElement(SiteShell, {
    currentPage: currentPage,
    navigate: navigate
  }, PAGES[currentPage](navigate));
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(/*#__PURE__*/React.createElement(THHGWebsite, null));