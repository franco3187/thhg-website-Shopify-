// Our Story — /why — business-card QR destination. DO NOT rename route.

function OurStoryPage({ navigate }) {
  return (
    <>
      <PageHero
        eyebrow="Our story"
        title="Before the brand, there was a dog named April."
        subtitle="She came to us as a rescue, changed everything about how we saw the world, and left us with a mission we couldn't ignore. This is how love became a purpose."
        badge={{
          title: 'Our Why',
          eyebrow: 'Built from purpose',
          highlight: 'From grief to good',
          copy: "The Happy Hunting Grounds is named after the place dogs go when they leave us — and built to honor them while they're still here.",
        }}
        cta={{ label: 'Shop the mission', secondary: 'See lives changed', onSecondary: () => navigate('lives-changed') }}
        onCta={() => navigate('shop')}
      />

      <Marquee items={['April', 'Healing', 'Rescue', 'Second chances', 'Good vibes save lives']} />

      {/* Hero gallery band */}
      <section style={{ background: C.navy }}>
        <div className="grid sm:grid-cols-3">
          {[
            { label: 'APRIL — RED RUFFLE', tone: 'warm' },
            { label: 'APRIL + FRANCO', tone: 'red' },
            { label: 'APRIL AT REST', tone: 'navy' },
          ].map((p, i) => (
            <Placeholder key={i} label={p.label} aspect="1/1" tone={p.tone} />
          ))}
        </div>
      </section>

      <section className="py-16 sm:py-20 md:py-24" style={{ background: C.creamLt }}>
        <div className="mx-auto grid max-w-7xl gap-10 px-5 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:px-8">
          <div className="p-8 sm:p-10" style={{ background: C.cream, borderTop: `4px solid ${C.gold}`, boxShadow: '0 20px 60px rgba(15,26,46,0.08)' }}>
            <SectionHeader
              eyebrow="How it started"
              title="Before the brand, there was love."
              copy="April was a rescue who came into a life that needed her. She gave companionship, healing, and joy in a season that needed all three. When she passed, the grief was real — but so was the clarity about what to do next."
            />
            <p className="thhg-baskerville mt-6 text-[15px] leading-[1.85]" style={{ color: C.brown }}>
              The Happy Hunting Grounds is named after the place dogs go when they leave us. Building this brand was
              a way to honor April by helping other dogs find the second chances she gave us. Every purchase, every
              product, every rescue spotlight carries her forward.
            </p>
            <blockquote className="thhg-playfair mt-7 border-l-[3px] pl-5 text-[19px] italic leading-[1.6]" style={{ color: C.navy2, borderColor: C.red }}>
              "We didn't build this to become a brand. We built it because the love was too big to stay quiet."
            </blockquote>
            <button
              onClick={() => navigate('shop')}
              className="thhg-oswald mt-7 inline-flex items-center gap-2 border-b-2 pb-1 text-xs font-semibold uppercase tracking-[0.24em]"
              style={{ color: C.red, borderColor: C.red }}
            >
              Shop with purpose →
            </button>
          </div>

          <div className="grid content-start gap-4">
            {[
              { value: 'April',     label: 'The heart behind the name' },
              { value: 'Rescue',    label: 'Every dog deserves a second chance' },
              { value: 'Healing',   label: 'Dogs heal people. Always have.' },
              { value: 'Community', label: 'Your tribe is already here' },
            ].map(({ value, label }) => (
              <div key={label} className="p-6" style={{ background: '#fff', border: `1px solid ${C.tan}`, boxShadow: '0 10px 30px rgba(15,26,46,0.05)' }}>
                <div className="thhg-rye text-3xl" style={{ color: C.red }}>{value}</div>
                <div className="thhg-oswald mt-2 text-xs uppercase tracking-[0.2em]" style={{ color: C.brown }}>{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-20" style={{ background: C.cream }}>
        <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
          <div className="mb-10">
            <SectionHeader eyebrow="Three chapters" title="Love. Loss. Purpose." align="center" />
          </div>
          <CardGrid items={[
            { eyebrow: 'Chapter one', title: 'Love', copy: "April arrived as a rescue and stayed as the foundation of everything. She showed what a second chance can become when someone decides to show up.", media: <Placeholder label="CH. 1 — LOVE" aspect="4/3" tone="warm" /> },
            { eyebrow: 'Chapter two', title: 'Loss', copy: "When April passed, the grief was the kind that doesn't leave. But grief rooted in real love has direction — and this brand is the direction ours took.", media: <Placeholder label="CH. 2 — LOSS" aspect="4/3" tone="navy" /> },
            { eyebrow: 'Chapter three', title: 'Purpose', copy: "The mission became the answer to loss: help more dogs, support more rescues, and fund the kind of healing that only dogs can give.", media: <Placeholder label="CH. 3 — PURPOSE" aspect="4/3" tone="red" /> },
          ]} />
        </div>
      </section>
    </>
  );
}

window.OurStoryPage = OurStoryPage;
