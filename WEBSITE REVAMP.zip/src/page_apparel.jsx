function ApparelPage({ navigate }) {
  const products = [
    { eyebrow: 'Best seller', title: 'Good Vibes Save Lives Tee', copy: 'The signature line, on the signature piece. Heavyweight cotton, vintage-washed feel, and a message the whole tribe can wear.', cta: 'Choose options', onCta: () => {}, media: <Placeholder label="GVSL TEE" aspect="1/1" tone="warm" /> },
    { eyebrow: 'Best seller', title: 'Your Vibe Attracts Your Tribe Hoodie', copy: 'The flagship pullover. Built for the person who finds their people through what they believe, not just where they live.', cta: 'Choose options', onCta: () => {}, media: <Placeholder label="TRIBE HOODIE" aspect="1/1" tone="navy" /> },
    { eyebrow: 'Best seller', title: 'Second Chances Hat', copy: 'A clean, mission-forward cap that carries the brand without saying everything at once.', cta: 'Choose options', onCta: () => {}, media: <Placeholder label="TRIBE CAP" aspect="1/1" tone="red" /> },
    { eyebrow: 'New', title: 'April Memorial Longsleeve', copy: 'Limited drop. Printed with love, in her honor. A portion supports shelter enrichment programs.', cta: 'Choose options', onCta: () => {}, media: <Placeholder label="APRIL LONGSLEEVE" aspect="1/1" tone="navy" /> },
    { eyebrow: 'Coming soon', title: 'Rescue Crewneck', copy: 'Heavyweight fleece, heritage-inspired graphics, and the tribe feeling built right in.', cta: 'Notify me', onCta: () => {}, media: <Placeholder label="RESCUE CREW" aspect="1/1" tone="warm" /> },
    { eyebrow: 'Accessory', title: 'Tribe Patch Set', copy: 'Iron-on patches for jackets, bags, or anything that needs a little more mission on it.', cta: 'Add to cart', onCta: () => {}, media: <Placeholder label="PATCH SET" aspect="1/1" tone="red" /> },
  ];

  return (
    <>
      <PageHero
        eyebrow="Second Chance Apparel"
        title="Wear the mission. Build the tribe."
        subtitle="Heritage-inspired pieces that feel like the culture behind them. Bold, built to last, and rooted in a story worth wearing."
        badge={{ title: 'Apparel', eyebrow: 'Wear the mission', highlight: 'Second Chance Collection', copy: 'Every piece carries the brand voice, the vintage styling, and a portion goes back to rescue.' }}
      />
      <Marquee items={['Wear the mission', 'Second Chance Collection', 'Built to last', 'Good vibes save lives']} />

      <section className="py-16 sm:py-20 md:py-24" style={{ background: C.creamLt }}>
        <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
          <div className="mb-10">
            <SectionHeader eyebrow="Current drop" title="Merch built for the tribe." copy="These aren't just shirts. They're a statement — second chances, real community, and good vibes that actually save lives." />
          </div>
          <CardGrid items={products} />
        </div>
      </section>
    </>
  );
}

window.ApparelPage = ApparelPage;
