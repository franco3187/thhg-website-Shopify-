// Site shell: sticky header, mobile nav, footer
// -----------------------------------------------------------------------------

const NAV_ITEMS = [
  { id: 'home',          label: 'Home' },
  { id: 'our-story',     label: 'Our Story' },
  { id: 'shop',          label: 'Shop' },
  { id: 'apparel',       label: 'Apparel' },
  { id: 'munchables',    label: 'Munchables' },
  { id: 'lives-changed', label: 'Lives Changed' },
  { id: 'contact',       label: 'Contact' },
];

function SiteShell({ currentPage, navigate, children }) {
  const [menuOpen, setMenuOpen] = React.useState(false);

  const go = React.useCallback((id) => {
    navigate(id);
    setMenuOpen(false);
  }, [navigate]);

  return (
    <div className="min-h-screen" style={{ background: C.cream, color: C.ink }}>

      <header className="sticky top-0 z-40 backdrop-blur" style={{ background: 'rgba(15,26,46,0.96)', borderBottom: `3px solid ${C.gold}` }}>
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">

          <button onClick={() => go('home')} className="flex items-center gap-3 text-left">
            <LogoMark size={44} />
            <div className="hidden sm:block">
              <div className="thhg-rye text-sm sm:text-[15px]" style={{ color: C.cream }}>The Happy Hunting Grounds</div>
              <div className="thhg-oswald mt-0.5 text-[10px] uppercase tracking-[0.28em]" style={{ color: C.gold }}>
                Good vibes save lives
              </div>
            </div>
            <div className="sm:hidden">
              <div className="thhg-rye text-sm" style={{ color: C.cream }}>THHG</div>
              <div className="thhg-oswald mt-0.5 text-[9px] uppercase tracking-[0.22em]" style={{ color: C.gold }}>
                Good vibes save lives
              </div>
            </div>
          </button>

          <nav className="hidden items-center gap-6 xl:flex" aria-label="Primary navigation">
            {NAV_ITEMS.map(({ id, label }) => (
              <button
                key={id}
                onClick={() => go(id)}
                className="thhg-oswald text-[12px] uppercase tracking-[0.18em] transition"
                style={{ color: currentPage === id ? C.goldLt : C.cream }}
              >
                {label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2 sm:gap-3">
            <a
              href="https://instagram.com/thehappyhuntinggrounds"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
              title="Instagram — follow along"
              className="hidden sm:inline-flex h-10 w-10 items-center justify-center border transition hover:-translate-y-0.5"
              style={{ borderColor: 'rgba(245,237,216,0.25)', color: C.cream }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
              </svg>
            </a>

            <button
              onClick={() => go('shop')}
              className="thhg-shine thhg-oswald px-3 py-2 text-[10px] font-semibold uppercase tracking-[0.18em] sm:px-4 sm:text-xs"
              style={{ background: C.red, color: C.cream, border: `1px solid rgba(255,255,255,0.1)` }}
            >
              Shop
            </button>

            <button
              onClick={() => setMenuOpen((v) => !v)}
              aria-expanded={menuOpen}
              aria-label={menuOpen ? 'Close menu' : 'Open menu'}
              className="xl:hidden flex flex-col justify-center gap-[5px] p-2"
            >
              <span className={`block h-0.5 w-6 origin-center transition-all ${menuOpen ? 'translate-y-[7px] rotate-45' : ''}`} style={{ background: C.cream }} />
              <span className={`block h-0.5 w-6 transition-opacity ${menuOpen ? 'opacity-0' : ''}`} style={{ background: C.cream }} />
              <span className={`block h-0.5 w-6 origin-center transition-all ${menuOpen ? '-translate-y-[7px] -rotate-45' : ''}`} style={{ background: C.cream }} />
            </button>
          </div>
        </div>

        <div className={`thhg-mobile-nav xl:hidden ${menuOpen ? 'open' : ''}`} style={{ borderTop: '1px solid rgba(255,255,255,0.1)', background: C.navy }}>
          <div>
            <nav className="mx-auto flex flex-col px-4 py-2 sm:px-6" aria-label="Mobile navigation">
              {NAV_ITEMS.map(({ id, label }) => (
                <button
                  key={id}
                  onClick={() => go(id)}
                  className="thhg-oswald py-3 text-left text-sm uppercase tracking-[0.18em]"
                  style={{ color: currentPage === id ? C.goldLt : C.cream, borderBottom: '1px solid rgba(255,255,255,0.06)' }}
                >
                  {label}
                </button>
              ))}
              <a
                href="https://instagram.com/thehappyhuntinggrounds"
                target="_blank"
                rel="noopener noreferrer"
                className="thhg-oswald py-3 text-left text-sm uppercase tracking-[0.18em]"
                style={{ color: C.gold }}
              >
                Instagram ↗
              </a>
            </nav>
          </div>
        </div>
      </header>

      <main id="main-content" data-screen-label={currentPage}>{children}</main>

      <footer className="px-4 py-14 sm:px-6 lg:px-8" style={{ background: C.navy, color: C.cream, borderTop: `3px solid ${C.gold}` }}>
        <div className="mx-auto grid max-w-7xl gap-10 lg:grid-cols-[1.4fr_0.6fr_0.6fr]">
          <div>
            <div className="flex items-center gap-4">
              <LogoMark size={64} />
              <div>
                <div className="thhg-rye text-2xl sm:text-3xl">The Happy Hunting Grounds</div>
                <div className="thhg-oswald mt-1 text-[11px] uppercase tracking-[0.28em]" style={{ color: C.gold }}>
                  Good vibes save lives
                </div>
              </div>
            </div>
            <p className="thhg-baskerville mt-5 max-w-xl text-sm leading-[1.85]" style={{ color: '#E7D9BE' }}>
              Built from rescue, healing, and second chances. Every purchase funds shelter dogs, supports veterans,
              and keeps April's spirit moving forward in the world.
            </p>
          </div>

          <nav className="content-start" aria-label="Footer navigation">
            <div className="thhg-oswald mb-4 text-[11px] uppercase tracking-[0.28em]" style={{ color: C.gold }}>Explore</div>
            <div className="grid grid-cols-2 gap-3 lg:grid-cols-1">
              {NAV_ITEMS.map(({ id, label }) => (
                <button
                  key={id}
                  onClick={() => go(id)}
                  className="thhg-oswald text-left text-xs uppercase tracking-[0.18em] transition hover:text-white"
                  style={{ color: C.tan }}
                >
                  {label}
                </button>
              ))}
            </div>
          </nav>

          <div>
            <div className="thhg-oswald mb-4 text-[11px] uppercase tracking-[0.28em]" style={{ color: C.gold }}>Follow</div>
            <a
              href="https://instagram.com/thehappyhuntinggrounds"
              target="_blank"
              rel="noopener noreferrer"
              className="thhg-rye block text-xl transition hover:text-white"
              style={{ color: C.cream }}
            >
              @thehappyhuntinggrounds
            </a>
            <p className="thhg-baskerville mt-3 text-xs leading-6" style={{ color: '#C8C0B0' }}>
              Where we show exactly where the money goes — rescues, receipts, and stories in real time.
            </p>
          </div>
        </div>

        <Rule color={C.gold} className="mx-auto mt-12 max-w-7xl opacity-40" />

        <div className="mx-auto mt-6 flex max-w-7xl flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="thhg-oswald text-[11px] uppercase tracking-[0.2em]" style={{ color: C.gold }}>
            © {new Date().getFullYear()} The Happy Hunting Grounds · For April
          </p>
          <p className="thhg-mono text-[10px] uppercase tracking-[0.2em]" style={{ color: C.tan, opacity: 0.7 }}>
            Shop with purpose / Built with love
          </p>
        </div>
      </footer>
    </div>
  );
}

Object.assign(window, { SiteShell, NAV_ITEMS });
