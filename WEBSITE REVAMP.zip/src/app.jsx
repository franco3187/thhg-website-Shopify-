// Router & mount

const PAGES = {
  'home':          (nav) => <HomePage navigate={nav} />,
  'our-story':     (nav) => <OurStoryPage navigate={nav} />,
  'why':           (nav) => <OurStoryPage navigate={nav} />, // business-card QR alias
  'shop':          (nav) => <ShopPage navigate={nav} />,
  'apparel':       (nav) => <ApparelPage navigate={nav} />,
  'munchables':    (nav) => <MunchablesPage navigate={nav} />,
  'lives-changed': (nav) => <LivesChangedPage navigate={nav} />,
  'contact':       (nav) => <ContactPage navigate={nav} />,
};

function THHGWebsite() {
  // Persist page to localStorage + hash
  const initial = (() => {
    const hash = window.location.hash.replace('#', '');
    if (hash && PAGES[hash]) return hash;
    const saved = localStorage.getItem('thhg-page');
    if (saved && PAGES[saved]) return saved;
    return 'home';
  })();

  const [currentPage, setCurrentPage] = React.useState(initial);

  const navigate = React.useCallback((id) => {
    const target = PAGES[id] ? id : 'home';
    setCurrentPage(target);
    localStorage.setItem('thhg-page', target);
    window.location.hash = target;
  }, []);

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [currentPage]);

  React.useEffect(() => {
    const onHash = () => {
      const h = window.location.hash.replace('#', '');
      if (h && PAGES[h] && h !== currentPage) setCurrentPage(h);
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, [currentPage]);

  return (
    <SiteShell currentPage={currentPage} navigate={navigate}>
      {PAGES[currentPage](navigate)}
    </SiteShell>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<THHGWebsite />);
