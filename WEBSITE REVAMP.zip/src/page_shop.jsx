function ShopPage({ navigate }) {
  const collections = [
    { eyebrow: 'Apparel',  title: 'Second Chance Collection', copy: 'Heritage-style hoodies, tees, and caps that carry the mission on their sleeve.', cta: 'View collection', onCta: () => navigate('apparel'), media: <Placeholder label="APPAREL" aspect="4/5" tone="navy" /> },
    { eyebrow: 'Treats',   title: 'Munchables',               copy: 'Single-ingredient, all-natural treats for good dogs. Made with care. Sold with purpose.', cta: 'Shop treats', onCta: () => navigate('munchables'), media: <Placeholder label="MUNCHABLES" aspect="4/5" tone="warm" /> },
    { eyebrow: 'Story',    title: 'The THHG Book',            copy: 'A story written for every family who has loved and lost a dog. Warm, honest, illustrated with heart.', cta: 'View the book', onCta: () => navigate('our-story'), media: <Placeholder label="THE BOOK" aspect="4/5" tone="red" /> },
    { eyebrow: 'Mission',  title: 'Rescue Taws',              copy: 'A product line built to let people support shelter enrichment while getting something meaningful.', cta: 'Explore', onCta: () => navigate('shop'), media: <Placeholder label="RESCUE TAWS" aspect="4/5" tone="navy" /> },
    { eyebrow: 'Seasonal', title: 'Featured Donations',       copy: 'Seasonal fundraising for urgent shelter needs — wobblers, beds, vet care, and more.', cta: 'Support now', onCta: () => navigate('lives-changed'), media: <Placeholder label="SEASONAL DRIVE" aspect="4/5" tone="red" /> },
    { eyebrow: 'Bundles',  title: 'Gift With Purpose',        copy: 'Packages built for gift-givers who want their purchase to do more than just wrap nicely.', cta: 'See bundles', onCta: () => navigate('shop'), media: <Placeholder label="GIFT BUNDLES" aspect="4/5" tone="warm" /> },
  ];

  return (
    <>
      <PageHero
        eyebrow="Shop with purpose"
        title="Every product carries the mission forward."
        subtitle="Six collections. One mission. Whether you're shopping for yourself, a dog, or someone who loves both — every purchase here goes further than most."
        badge={{
          title: 'The Shop',
          eyebrow: 'Storefront',
          highlight: 'Purpose in every order',
          copy: '25% minimum of every sale goes back to rescue, shelter support, and healing-focused programs.',
        }}
      />
      <Marquee items={['Apparel', 'Treats', 'Books', 'Bundles', 'Mission-driven']} tone="red" />
      <section className="py-16 sm:py-20 md:py-24" style={{ background: C.cream }}>
        <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
          <div className="mb-10 md:mb-12">
            <SectionHeader eyebrow="All collections" title="Shop by what moves you." copy="From apparel to treats to the book that started it all — every collection is built around the mission." />
          </div>
          <CardGrid items={collections} />
        </div>
      </section>
    </>
  );
}

window.ShopPage = ShopPage;
