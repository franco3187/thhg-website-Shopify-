const DONATION_LOG = [
  { period: 'Q1 2024', item: '12 shelter beds',   org: 'Local rescue partners', detail: 'Sponsored comfort bedding for 12 dogs in active foster care, funded through Second Chance Apparel sales.' },
  { period: 'Q4 2023', item: '8 enrichment toys', org: 'County animal shelter', detail: 'Wobbler-style enrichment tools donated to reduce stress in long-stay shelter dogs during the holiday surge.' },
  { period: 'Q3 2023', item: 'Emergency vet fund',org: 'Independent rescue',    detail: 'Contributed to emergency medical care for a dog pulled from an urgent euthanasia situation.' },
];

const INSTA_POSTS = [
  { label: 'SHELTER BEDS — Q1', tag: 'PROOF' },
  { label: 'QUACKERS RESTOCK', tag: 'NEW' },
  { label: 'FOR APRIL', tag: 'STORY' },
  { label: 'GOOD VIBES', tag: 'VLOG' },
  { label: 'RESCUE SPOTLIGHT', tag: 'LIVE' },
  { label: 'SECOND CHANCE', tag: 'DROP' },
];

function LivesChangedPage({ navigate }) {
  return (
    <>
      <PageHero
        eyebrow="Lives changed"
        title="Your support documented. No vague promises."
        subtitle="Every donation this brand makes is logged and shared here. Dogs helped. Beds funded. Treatments covered. This is the proof of mission."
        badge={{ title: 'Lives Changed', eyebrow: 'Proof of impact', highlight: 'Show the receipts', copy: 'Accountability is how a mission-driven brand earns real trust. We document everything.' }}
      />
      <Marquee items={['Beds funded', 'Enrichment donated', 'Rescue support', 'Vet care', 'Show the receipts']} />

      <section className="py-16 sm:py-20 md:py-24" style={{ background: C.creamLt }}>
        <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
          <div className="mb-10 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
            <SectionHeader eyebrow="Donation log" title="Where your money actually went." copy="Updated quarterly. Every entry is a real donation tied to a real product sale." />
            <button onClick={() => navigate('shop')} className="thhg-oswald shrink-0 self-start border-b-2 pb-1 text-[11px] font-semibold uppercase tracking-[0.24em]" style={{ color: C.navy2, borderColor: C.navy2 }}>Shop to add more →</button>
          </div>

          <div className="grid gap-6">
            {DONATION_LOG.map(({ period, item, org, detail }) => (
              <div key={period} className="grid overflow-hidden sm:grid-cols-[220px_1fr]" style={{ background: '#fff', border: `1px solid ${C.tan}`, boxShadow: '0 10px 30px rgba(15,26,46,0.05)' }}>
                <div className="p-6" style={{ background: `linear-gradient(160deg, ${C.navy}, ${C.navy2})` }}>
                  <div className="thhg-oswald text-[10px] uppercase tracking-[0.22em]" style={{ color: C.goldLt }}>Period</div>
                  <div className="thhg-rye mt-2 text-xl" style={{ color: C.cream }}>{period}</div>
                  <StarRow color={C.gold} size="text-xs" />
                </div>
                <div className="p-6">
                  <div className="thhg-rye text-2xl" style={{ color: C.navy2 }}>{item}</div>
                  <div className="thhg-oswald mt-1 text-xs uppercase tracking-[0.18em]" style={{ color: C.red }}>{org}</div>
                  <p className="thhg-baskerville mt-3 text-sm leading-7" style={{ color: C.brown }}>{detail}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-20" style={{ background: C.cream }}>
        <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
          <div className="mb-10">
            <SectionHeader eyebrow="Where your support lands" title="Three places every dollar flows." align="center" />
          </div>
          <CardGrid items={[
            { eyebrow: 'What we fund', title: 'Shelter essentials', copy: 'Beds, blankets, enrichment toys, and comfort items for dogs in active shelter care while they wait for their homes.', cta: 'Support now', onCta: () => navigate('shop'), media: <Placeholder label="SHELTER ESSENTIALS" aspect="4/3" tone="warm" /> },
            { eyebrow: 'What we fund', title: 'Emergency vet care', copy: 'When rescue partners pull dogs from urgent situations, we contribute to immediate veterinary needs.', cta: 'Support now', onCta: () => navigate('shop'), media: <Placeholder label="VET CARE" aspect="4/3" tone="red" /> },
            { eyebrow: 'What we fund', title: 'Veteran programs', copy: 'Dog-assisted healing programs for veterans. Because dogs heal people — and that healing is worth funding.', cta: 'Support now', onCta: () => navigate('shop'), media: <Placeholder label="VETERAN HEALING" aspect="4/3" tone="navy" /> },
          ]} />
        </div>
      </section>

      <section className="relative py-16 sm:py-20 md:py-24" style={{ background: C.navy, color: C.cream }}>
        <div className="pointer-events-none absolute inset-0 opacity-[0.06]" style={{ backgroundImage: `radial-gradient(${C.cream} 1px, transparent 1px)`, backgroundSize: '24px 24px' }} />
        <div className="relative mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
          <div className="mb-10 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <Eyebrow color={C.goldLt}>Follow along</Eyebrow>
              <h2 className="thhg-rye mt-4 text-3xl sm:text-4xl md:text-5xl" style={{ color: C.cream }}>@thehappyhuntinggrounds</h2>
              <p className="thhg-baskerville mt-4 max-w-xl text-[15px] leading-[1.85]" style={{ color: '#E7D9BE' }}>This is where the receipts live — posted the moment every bed gets funded, every dog gets spotlighted, every receipt comes in.</p>
            </div>
            <a href="https://instagram.com/thehappyhuntinggrounds" target="_blank" rel="noopener noreferrer" className="thhg-shine thhg-oswald shrink-0 self-start border-2 px-5 py-3 text-xs font-semibold uppercase tracking-[0.22em]" style={{ color: C.cream, borderColor: C.gold }}>Follow on Instagram ↗</a>
          </div>

          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
            {INSTA_POSTS.map((p, i) => (
              <a key={i} href="https://instagram.com/thehappyhuntinggrounds" target="_blank" rel="noopener noreferrer" className="thhg-card relative block aspect-square overflow-hidden">
                <Placeholder label={p.label} aspect="1/1" tone={i % 3 === 0 ? 'navy' : i % 3 === 1 ? 'red' : 'warm'} className="h-full" />
                <div className="thhg-oswald absolute left-2 top-2 px-2 py-1 text-[9px] font-semibold uppercase tracking-[0.18em]" style={{ background: C.gold, color: C.navy }}>{p.tag}</div>
              </a>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

window.LivesChangedPage = LivesChangedPage;
