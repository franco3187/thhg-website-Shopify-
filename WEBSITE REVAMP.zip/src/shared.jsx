// Shared UI: placeholders, icons, marquee, section headers, cards, hero
// Exposes: Placeholder, LogoMark, StarRow, Marquee, Eyebrow, SectionHeader,
//          CardGrid, StatCard, Rule, PageHero, ScrollReveal, useTweaks
// -----------------------------------------------------------------------------

const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ─── Palette constants ────────────────────────────────────────────────────────
const C = {
  navy:   '#0F1A2E',
  navy2:  '#1B2A4A',
  red:    '#B5282A',
  redDk:  '#7A1A1C',
  gold:   '#C8882A',
  goldLt: '#E8A83A',
  cream:  '#F5EDD8',
  creamLt:'#FDFAF4',
  tan:    '#D4B483',
  ink:    '#1C1510',
  brown:  '#4A3822',
};

// ─── Tweaks hook ──────────────────────────────────────────────────────────────
function useTweaks() {
  const [t, setT] = useState(window.__thhgTweaks || { heroVariant: 'badge' });
  useEffect(() => {
    const h = () => setT({ ...window.__thhgTweaks });
    window.addEventListener('thhg-tweaks-changed', h);
    return () => window.removeEventListener('thhg-tweaks-changed', h);
  }, []);
  return t;
}

// ─── Logo mark — uses the uploaded THHG logo image ────────────────────────────
function LogoMark({ size = 48, animate = true }) {
  return (
    <div
      className={`${animate ? 'thhg-logo-pop' : ''} relative shrink-0 overflow-hidden rounded-full`}
      style={{
        width: size, height: size,
        background: '#fff',
      }}
      aria-hidden="true"
    >
      <img
        src="assets/thhg-logo.jpeg"
        alt="The Happy Hunting Grounds"
        style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
      />
    </div>
  );
}

// ─── Placeholder image block ──────────────────────────────────────────────────
function Placeholder({ label, aspect = '4/3', tone = 'navy', className = '', children }) {
  const toneClass =
    tone === 'warm' ? 'thhg-placeholder-warm' :
    tone === 'red'  ? 'thhg-placeholder-red'  :
                      'thhg-placeholder';
  const labelColor = tone === 'warm' ? C.brown : C.cream;
  return (
    <div
      className={`relative overflow-hidden ${toneClass} ${className}`}
      style={{ aspectRatio: aspect }}
    >
      <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center">
        <div
          className="thhg-mono text-[10px] uppercase tracking-[0.22em]"
          style={{ color: labelColor, opacity: 0.7 }}
        >
          ▸ {label}
        </div>
        {children}
      </div>
    </div>
  );
}

// ─── Star row ─────────────────────────────────────────────────────────────────
function StarRow({ color = C.gold, size = 'text-base', count = 3 }) {
  return (
    <div className={`thhg-star-pop inline-flex gap-2 ${size}`} style={{ color }} aria-hidden="true">
      {Array.from({ length: count }).map((_, i) => <span key={i}>★</span>)}
    </div>
  );
}

// ─── Marquee band ─────────────────────────────────────────────────────────────
function Marquee({ items, tone = 'gold' }) {
  const track = useMemo(() => [...items, ...items, ...items, ...items], [items]);
  const bg = tone === 'gold' ? C.gold : tone === 'red' ? C.red : C.navy;
  const fg = tone === 'gold' ? C.navy : C.cream;
  const accent = tone === 'gold' ? C.red : C.gold;
  return (
    <div
      className="overflow-hidden py-3 sm:py-4"
      style={{
        background: bg,
        borderTop: `2px solid ${accent}`,
        borderBottom: `2px solid ${accent}`,
      }}
      aria-hidden="true"
    >
      <div className="thhg-marquee flex w-max items-center gap-x-6 sm:gap-x-8">
        {track.map((item, i) => (
          <div key={i} className="thhg-rye flex shrink-0 items-center gap-4 sm:gap-6 text-sm sm:text-base" style={{ color: fg }}>
            <span>{item}</span>
            <span style={{ color: accent }}>★</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Eyebrow ─────────────────────────────────────────────────────────────────
function Eyebrow({ children, color = C.red, className = '' }) {
  return (
    <div className={`thhg-oswald inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.28em] ${className}`} style={{ color }}>
      <span>★</span>
      <span>{children}</span>
      <span>★</span>
    </div>
  );
}

// ─── Section header ──────────────────────────────────────────────────────────
function SectionHeader({ eyebrow, title, copy, align = 'left', titleColor, eyebrowColor = C.red }) {
  const alignClass = align === 'center' ? 'mx-auto text-center' : '';
  return (
    <div className={`max-w-3xl ${alignClass}`}>
      <Eyebrow color={eyebrowColor}>{eyebrow}</Eyebrow>
      <h2 className="thhg-rye mt-4 text-3xl leading-[1.1] sm:text-4xl md:text-5xl" style={{ color: titleColor || C.navy2 }}>
        {title}
      </h2>
      {copy && (
        <p className="thhg-baskerville mt-5 text-base leading-[1.75] sm:text-[17px]" style={{ color: C.brown }}>
          {copy}
        </p>
      )}
    </div>
  );
}

// ─── Western rule ────────────────────────────────────────────────────────────
function Rule({ className = '', color = C.red }) {
  return (
    <div className={`flex items-center gap-3 ${className}`} aria-hidden="true">
      <div className="h-px flex-1" style={{ background: `linear-gradient(90deg, transparent, ${color}, transparent)` }} />
      <span style={{ color }}>★</span>
      <div className="h-px flex-1" style={{ background: `linear-gradient(90deg, transparent, ${color}, transparent)` }} />
    </div>
  );
}

// ─── Card grid ────────────────────────────────────────────────────────────────
function CardGrid({ items, dark = false, cols = 3 }) {
  const colsClass = cols === 2 ? 'sm:grid-cols-2' : 'sm:grid-cols-2 lg:grid-cols-3';
  return (
    <div className={`grid gap-5 sm:gap-6 ${colsClass}`}>
      {items.map((item, i) => (
        <article
          key={item.title + i}
          className="thhg-card group relative overflow-hidden border"
          style={{
            background: dark ? 'rgba(255,255,255,0.04)' : '#fff',
            borderColor: dark ? 'rgba(255,255,255,0.12)' : C.tan,
            boxShadow: dark ? 'none' : '0 14px 40px rgba(15,26,46,0.07)',
          }}
        >
          {item.media && (
            <div className="relative">
              {item.media}
              <div className="absolute left-0 top-0 m-3">
                <div
                  className="thhg-oswald px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.2em]"
                  style={{ background: C.cream, color: C.navy2 }}
                >
                  {item.eyebrow}
                </div>
              </div>
            </div>
          )}
          <div
            className="p-6"
            style={{ borderTop: item.media ? `3px solid ${C.gold}` : 'none' }}
          >
            {!item.media && (
              <div className="thhg-oswald text-[11px] uppercase tracking-[0.25em]" style={{ color: dark ? C.goldLt : C.red }}>
                {item.eyebrow}
              </div>
            )}
            <h3 className="thhg-rye mt-3 text-2xl leading-tight sm:text-[26px]" style={{ color: dark ? C.cream : C.navy2 }}>
              {item.title}
            </h3>
            <p className="thhg-baskerville mt-3 text-sm leading-7" style={{ color: dark ? '#E7D9BE' : C.brown }}>
              {item.copy}
            </p>
            {item.cta && (
              <button
                onClick={item.onCta}
                className="thhg-oswald mt-5 inline-flex items-center gap-2 border-b-2 pb-1 text-[11px] font-semibold uppercase tracking-[0.24em]"
                style={{ color: dark ? C.goldLt : C.red, borderColor: dark ? C.goldLt : C.red }}
              >
                {item.cta} <span>→</span>
              </button>
            )}
          </div>
        </article>
      ))}
    </div>
  );
}

// ─── Stat card ───────────────────────────────────────────────────────────────
function StatCard({ value, label }) {
  return (
    <div className="border bg-white p-6" style={{ borderColor: C.tan, boxShadow: '0 10px 30px rgba(15,26,46,0.05)' }}>
      <div className="thhg-rye text-4xl" style={{ color: C.red }}>{value}</div>
      <div className="thhg-oswald mt-2 text-[11px] uppercase tracking-[0.18em]" style={{ color: C.brown }}>{label}</div>
    </div>
  );
}

// ─── Scroll reveal ───────────────────────────────────────────────────────────
function ScrollReveal({ children, delay = 0, className = '' }) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { setVisible(true); obs.disconnect(); }
    }, { threshold: 0.1 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(24px)',
        transition: `opacity 700ms ease ${delay}ms, transform 700ms ease ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

// ─── Page Hero ───────────────────────────────────────────────────────────────
function PageHero({ eyebrow, title, subtitle, badge, cta, onCta, variant }) {
  const tweaks = useTweaks();
  const v = variant || tweaks.heroVariant || 'badge';

  return (
    <section className="relative overflow-hidden" style={{ background: C.navy }}>
      {/* Decorative radial glows */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          backgroundImage: `radial-gradient(circle at 15% 10%, rgba(200,136,42,0.16), transparent 42%), radial-gradient(circle at 88% 90%, rgba(181,40,42,0.18), transparent 38%)`,
        }}
      />
      {/* subtle dot grid */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.08]"
        style={{
          backgroundImage: `radial-gradient(${C.cream} 1px, transparent 1px)`,
          backgroundSize: '24px 24px',
        }}
      />

      <div className="relative mx-auto grid max-w-7xl gap-10 px-5 py-14 sm:px-6 sm:py-20 lg:grid-cols-[1.15fr_0.85fr] lg:gap-14 lg:px-8 lg:py-24">
        <div className="relative z-10">
          <Eyebrow color={C.goldLt}>{eyebrow}</Eyebrow>
          <h1 className="thhg-rye mt-5 max-w-2xl text-[38px] leading-[1.04] sm:text-5xl lg:text-[64px]" style={{ color: C.cream }}>
            {title}
          </h1>
          <div className="mt-6 max-w-md">
            <Rule color={C.red} />
          </div>
          <p className="thhg-baskerville mt-6 max-w-xl text-[15px] leading-[1.85] sm:text-[17px]" style={{ color: '#E7D9BE' }}>
            {subtitle}
          </p>
          {cta && (
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                onClick={onCta}
                className="thhg-shine thhg-oswald px-6 py-3.5 text-xs font-semibold uppercase tracking-[0.22em]"
                style={{ background: C.red, color: C.cream }}
              >
                {cta.label}
              </button>
              {cta.secondary && (
                <button
                  onClick={cta.onSecondary}
                  className="thhg-oswald border-b-2 pb-1 text-xs font-semibold uppercase tracking-[0.22em]"
                  style={{ color: C.goldLt, borderColor: C.goldLt }}
                >
                  {cta.secondary} →
                </button>
              )}
            </div>
          )}
        </div>

        <div className="relative z-10 flex items-center justify-center">
          {v === 'badge' && <HeroBadge badge={badge} />}
          {v === 'poster' && <HeroPoster badge={badge} />}
          {v === 'portrait' && <HeroPortrait badge={badge} />}
        </div>
      </div>

      {/* Deckle bottom edge */}
      <div className="relative h-3" style={{ background: C.gold }} />
    </section>
  );
}

function HeroBadge({ badge }) {
  return (
    <div className="thhg-hero-card w-full max-w-sm" style={{ border: `3px solid ${C.gold}`, background: C.cream, padding: 14, boxShadow: '0 16px 60px rgba(0,0,0,0.35)' }}>
      <div style={{ background: `linear-gradient(160deg, ${C.navy2}, #162038)`, padding: 20 }}>
        <div className="flex flex-col items-center border p-6 text-center" style={{ borderColor: 'rgba(255,255,255,0.12)', background: 'linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02))' }}>
          <StarRow color={C.gold} />
          <div className="mt-4">
            <LogoMark size={110} />
          </div>
          <div className="thhg-rye mt-4 text-xl" style={{ color: C.cream }}>The Happy Hunting Grounds</div>
          <div className="thhg-rye mt-1 text-lg" style={{ color: C.red }}>{badge.title}</div>
          <div className="mt-4 w-full p-4" style={{ borderTop: `4px solid ${C.gold}`, background: C.cream }}>
            <div className="thhg-oswald text-[10px] uppercase tracking-[0.25em]" style={{ color: C.navy2 }}>{badge.eyebrow}</div>
            <div className="thhg-rye mt-2 text-xl" style={{ color: C.navy2 }}>{badge.highlight}</div>
            <p className="thhg-baskerville mt-2 text-xs leading-6" style={{ color: C.brown }}>{badge.copy}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function HeroPoster({ badge }) {
  return (
    <div className="thhg-hero-card w-full max-w-sm" style={{ background: C.cream, padding: 18, border: `1px solid ${C.tan}`, boxShadow: '0 24px 60px rgba(0,0,0,0.4)' }}>
      <div className="relative p-8 text-center" style={{ border: `2px double ${C.red}` }}>
        <div className="thhg-oswald text-[10px] uppercase tracking-[0.32em]" style={{ color: C.red }}>EST. FOR APRIL · 2024</div>
        <Rule color={C.red} className="mt-3" />
        <div className="thhg-rye mt-5 text-3xl leading-[1]" style={{ color: C.navy }}>
          {badge.highlight}
        </div>
        <div className="my-5">
          <LogoMark size={88} />
        </div>
        <div className="thhg-rye text-xl leading-tight" style={{ color: C.red }}>
          {badge.title}
        </div>
        <p className="thhg-baskerville mt-3 text-xs leading-6" style={{ color: C.brown }}>
          {badge.copy}
        </p>
        <Rule color={C.red} className="mt-5" />
        <div className="thhg-oswald mt-4 text-[10px] uppercase tracking-[0.25em]" style={{ color: C.navy2 }}>{badge.eyebrow}</div>
      </div>
    </div>
  );
}

function HeroPortrait({ badge }) {
  return (
    <div className="thhg-hero-card relative w-full max-w-sm">
      <Placeholder label="APRIL — HERO PORTRAIT" aspect="3/4" tone="navy" className="border-[6px]" />
      <div
        className="absolute bottom-0 left-0 right-0 mx-4 -mb-6 p-5 text-center"
        style={{ background: C.cream, border: `2px solid ${C.gold}`, boxShadow: '0 18px 40px rgba(0,0,0,0.3)' }}
      >
        <div className="thhg-oswald text-[10px] uppercase tracking-[0.28em]" style={{ color: C.red }}>{badge.eyebrow}</div>
        <div className="thhg-rye mt-2 text-xl leading-tight" style={{ color: C.navy2 }}>{badge.highlight}</div>
      </div>
    </div>
  );
}

// ─── Expose globals ──────────────────────────────────────────────────────────
Object.assign(window, {
  C, LogoMark, Placeholder, StarRow, Marquee, Eyebrow, SectionHeader, Rule,
  CardGrid, StatCard, ScrollReveal, PageHero, useTweaks,
});
