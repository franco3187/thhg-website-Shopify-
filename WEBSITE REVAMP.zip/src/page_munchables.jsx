const MUNCHABLES_LINE = [
  { name: 'Quackers', ingredient: 'Duck',         copy: 'Single-ingredient duck bites. High-protein, grain-free, and something your dog will absolutely lose their mind over.',    tags: ['High protein', 'Grain-free', 'Novel protein'], price: '$14' },
  { name: 'Cluckers', ingredient: 'Chicken',      copy: 'Classic chicken strips, nothing else. The everyday treat that never gets old, from dogs who deserve the real thing.',     tags: ['Lean protein', 'Digestible', 'All ages'], price: '$12' },
  { name: 'Gobbler',  ingredient: 'Turkey',       copy: 'Low-fat turkey bites perfect for training, rewarding, or just because your dog had a really good day.',                   tags: ['Low fat', 'Training treat', 'Sensitive stomachs'], price: '$13' },
  { name: 'Mooers',   ingredient: 'Beef',         copy: 'Beef lung bites — chewy, satisfying, and packed with the nutrition that keeps tails wagging hard.',                       tags: ['Chewy', 'Rich flavor', 'High value reward'], price: '$14' },
  { name: 'Swimmer',  ingredient: 'Salmon',       copy: 'Omega-3 packed salmon treats for coat health, brain function, and dogs who appreciate something from the deep end.',      tags: ['Omega-3', 'Coat health', 'Brain support'], price: '$15' },
  { name: 'Rooters',  ingredient: 'Sweet Potato', copy: 'Plant-based sweet potato chews for dogs with sensitivities or owners who want a clean vegetarian option.',                tags: ['Vegetarian', 'Sensitivity-friendly', 'Fiber rich'], price: '$11' },
];

function MunchablesPage() {
  const [qtys, setQtys] = React.useState(() => Object.fromEntries(MUNCHABLES_LINE.map((p) => [p.name, 1])));
  const [cart, setCart] = React.useState(0);
  const [added, setAdded] = React.useState(null);

  const adjustQty = (name, fn) => setQtys((p) => ({ ...p, [name]: fn(p[name]) }));
  const addToCart = (name) => {
    setCart((c) => c + qtys[name]);
    setAdded(name);
    setTimeout(() => setAdded(null), 1400);
  };

  return (
    <>
      <PageHero
        eyebrow="Munchables by THHG"
        title="The complete treat line. One ingredient. Zero compromise."
        subtitle="Six flavors. All-natural, single-ingredient treats made for good dogs and owners who read the label. Every bag sold puts 25% back into rescue."
        badge={{ title: 'Munchables', eyebrow: 'The treat line', highlight: 'Single ingredient', copy: 'Duck, chicken, turkey, beef, salmon, sweet potato. Nothing else. Ever.' }}
      />
      <Marquee items={['Quackers', 'Cluckers', 'Gobbler', 'Mooers', 'Swimmer', 'Rooters', 'Single ingredient always']} />

      {cart > 0 && (
        <div className="sticky top-[68px] z-30 py-2.5 text-center" style={{ background: C.gold, color: C.navy, borderBottom: `2px solid ${C.red}` }}>
          <span className="thhg-oswald text-xs uppercase tracking-[0.22em]">★ {cart} bag{cart > 1 ? 's' : ''} in your cart ★</span>
        </div>
      )}

      <section className="py-16 sm:py-20 md:py-24" style={{ background: C.cream }}>
        <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
          <div className="mb-10">
            <SectionHeader eyebrow="The full line" title="Six flavors. All good dogs qualify." copy="Every Munchables treat is one ingredient — nothing added, nothing hidden. Sourced with the same intention that drives everything we make." />
          </div>

          <div className="grid gap-5 sm:gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {MUNCHABLES_LINE.map(({ name, ingredient, copy, tags, price }) => (
              <article key={name} className="thhg-card overflow-hidden border bg-white" style={{ borderColor: C.tan, boxShadow: '0 14px 40px rgba(15,26,46,0.07)' }}>
                <div className="relative" style={{ borderBottom: `3px solid ${C.gold}` }}>
                  <Placeholder label={`${name.toUpperCase()} — ${ingredient.toUpperCase()}`} aspect="4/3" tone={ingredient === 'Sweet Potato' ? 'warm' : ingredient === 'Beef' || ingredient === 'Salmon' ? 'red' : 'navy'} />
                  <div className="absolute right-3 top-3 thhg-oswald px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.18em]" style={{ background: C.cream, color: C.navy }}>{price}</div>
                </div>
                <div className="p-5 sm:p-6">
                  <div className="thhg-oswald text-[10px] uppercase tracking-[0.25em]" style={{ color: C.red }}>{ingredient}</div>
                  <div className="thhg-rye mt-1 text-2xl" style={{ color: C.navy2 }}>{name}</div>
                  <p className="thhg-baskerville mt-3 text-sm leading-7" style={{ color: C.brown }}>{copy}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {tags.map((t) => (
                      <span key={t} className="thhg-oswald px-2 py-1 text-[10px] uppercase tracking-[0.14em]" style={{ border: `1px solid ${C.tan}`, color: C.brown }}>{t}</span>
                    ))}
                  </div>
                  <div className="mt-5 flex items-center gap-3">
                    <div className="flex items-center" style={{ border: `1px solid ${C.tan}` }}>
                      <button onClick={() => adjustQty(name, (q) => Math.max(1, q - 1))} aria-label={`Decrease ${name}`} className="thhg-oswald px-3 py-2" style={{ color: C.navy2 }}>−</button>
                      <span className="thhg-oswald min-w-[2rem] px-2 py-2 text-center text-sm" style={{ color: C.navy2 }}>{qtys[name]}</span>
                      <button onClick={() => adjustQty(name, (q) => q + 1)} aria-label={`Increase ${name}`} className="thhg-oswald px-3 py-2" style={{ color: C.navy2 }}>+</button>
                    </div>
                    <button
                      onClick={() => addToCart(name)}
                      className="thhg-shine thhg-oswald flex-1 py-2.5 text-xs font-semibold uppercase tracking-[0.18em] transition"
                      style={{ background: added === name ? C.gold : C.red, color: added === name ? C.navy : C.cream }}
                    >
                      {added === name ? '★ Added ★' : 'Add to cart'}
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>

          <p className="thhg-baskerville mt-10 text-center text-xs" style={{ color: C.brown }}>
            ★ 25% of every Munchables purchase goes directly to shelter dog support programs.
          </p>
        </div>
      </section>
    </>
  );
}

window.MunchablesPage = MunchablesPage;
